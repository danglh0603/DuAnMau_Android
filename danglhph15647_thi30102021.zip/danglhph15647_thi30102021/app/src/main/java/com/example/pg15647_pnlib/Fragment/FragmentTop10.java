package com.example.pg15647_pnlib.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.pg15647_pnlib.Adapter.AdapterTop10;
import com.example.pg15647_pnlib.DAO.DAOThongKe;
import com.example.pg15647_pnlib.DTO.Top;
import com.example.pg15647_pnlib.R;

import java.util.ArrayList;

public class FragmentTop10 extends Fragment {
    ListView listView;
    ArrayList<Top> list;
    AdapterTop10 adapterTop10;
    DAOThongKe daoThongKe;

    public FragmentTop10() {
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @org.jetbrains.annotations.NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_top10, container, false);
        listView = view.findViewById(R.id.lst_Top10);
        list = new ArrayList<>();
        daoThongKe = new DAOThongKe(getContext());
        list = daoThongKe.getTop10();
        adapterTop10 = new AdapterTop10(getContext(), this, list);
        listView.setAdapter(adapterTop10);
        return view;
    }
}
