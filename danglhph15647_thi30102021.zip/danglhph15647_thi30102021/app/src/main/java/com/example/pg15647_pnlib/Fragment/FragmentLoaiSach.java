package com.example.pg15647_pnlib.Fragment;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pg15647_pnlib.Adapter.AdapterLoaiSach;
import com.example.pg15647_pnlib.DAO.DAOLoaiSach;
import com.example.pg15647_pnlib.DTO.LoaiSach;
import com.example.pg15647_pnlib.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class FragmentLoaiSach extends Fragment {
    RecyclerView recyclerView;
    ArrayList<LoaiSach> list;
    FloatingActionButton fab;

    EditText edDialogMaLS;
    EditText edDialogTenLS;
    Button btnDialogLuuLS;
    Button btnDialogHuyLS;

    static DAOLoaiSach daoLoaiSach;
    AdapterLoaiSach adapterLoaiSach;
    LoaiSach loaiSach;


    public FragmentLoaiSach() {
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @org.jetbrains.annotations.NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_loaisach, container, false);

        recyclerView = view.findViewById(R.id.rcv_LS);
        fab = view.findViewById(R.id.fl_add_LS);

        daoLoaiSach = new DAOLoaiSach(getActivity());

        fab.setOnClickListener(v -> openDialog(getContext(), 0));

        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(manager);
        capnhatLv();

        return view;
    }

    protected void openDialog(final Context context, final int type) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_loaisach, null);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
        //anh xa
        edDialogMaLS = view.findViewById(R.id.ed_dialogMaLS);
        edDialogTenLS = view.findViewById(R.id.ed_dialogTenLS);
        btnDialogLuuLS = view.findViewById(R.id.btn_dialogLuuLS);
        btnDialogHuyLS = view.findViewById(R.id.btn_dialogHuyLS);

        if (type != 0) {
            edDialogMaLS.setText(String.valueOf(loaiSach.getMaLoai()));
            edDialogTenLS.setText(loaiSach.getTenLoaiSach());
        }

        btnDialogHuyLS.setOnClickListener(v -> alertDialog.dismiss());

        btnDialogLuuLS.setOnClickListener(v -> {
            if (validate() > 0) {
                loaiSach = new LoaiSach();
                loaiSach.setTenLoaiSach(edDialogTenLS.getText().toString());
                if (type == 0) {
                    //insert
                    if (daoLoaiSach.insert(loaiSach) > 0) {
                        Toast.makeText(getContext(), "Thêm thành công!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Thêm thất bại!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    //update
                    loaiSach.setMaLoai(Integer.parseInt(edDialogMaLS.getText().toString()));
                    if (daoLoaiSach.update(loaiSach) > 0) {
                        Toast.makeText(getContext(), "Update thành công!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Update thất bại!", Toast.LENGTH_SHORT).show();
                    }
                }
                capnhatLv();
                alertDialog.dismiss();
            }
        });


    }

    public void xoa(final int id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_xoa, null);
        builder.setView(view);

        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();
        Button xoa = view.findViewById(R.id.btn_dialog_xoaTV);
        Button huy = view.findViewById(R.id.btn_dialog_huyTV);

        xoa.setOnClickListener(v -> {
            if (daoLoaiSach.delete(id) > 0) {
                capnhatLv();
                alertDialog.dismiss();
                Toast.makeText(getContext(), "Đã xóa", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Xóa thất bại!", Toast.LENGTH_SHORT).show();
            }
        });
        huy.setOnClickListener(v -> {
            alertDialog.dismiss();
            Toast.makeText(getContext(), "Đã hủy", Toast.LENGTH_SHORT).show();
        });

    }

    public void update(final int position) {
        loaiSach = list.get(position);
        openDialog(getContext(), 1);
    }

    void capnhatLv() {
        list = daoLoaiSach.getAll();
        adapterLoaiSach = new AdapterLoaiSach(getContext(), this, list);
        recyclerView.setAdapter(adapterLoaiSach);
    }

    public int validate() {
        int check = 1;
        if (edDialogTenLS.getText().toString().length() == 0) {
            Toast.makeText(getContext(), "Không để trống tên loại sách!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (edDialogTenLS.getText().toString().length() < 5 ||
                edDialogTenLS.getText().toString().length() > 20) {
            Toast.makeText(getContext(), "Tối thiểu 5 kí tự! , Tối đa 20 kí tự", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        String title = edDialogTenLS.getText().toString();
        String first = title.substring(0);
        if (!first.matches("^[0-9].*")) {
            Toast.makeText(getContext(), "Tên loại sách phải bắt đầu bằng số!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }

        return check;
    }

}
