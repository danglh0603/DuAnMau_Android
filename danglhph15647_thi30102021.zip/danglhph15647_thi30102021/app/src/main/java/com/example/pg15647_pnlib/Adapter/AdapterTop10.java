package com.example.pg15647_pnlib.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.pg15647_pnlib.DTO.Top;
import com.example.pg15647_pnlib.Fragment.FragmentTop10;
import com.example.pg15647_pnlib.R;

import java.util.ArrayList;

public class AdapterTop10 extends ArrayAdapter<Top> {
    private Context context;
    FragmentTop10 fragmentTop10;
    private ArrayList<Top> list;
    TextView tv_TenSach, tv_SoLuong;

    public AdapterTop10(@NonNull Context context, FragmentTop10 fragmentTop10, ArrayList<Top> list) {
        super(context, 0, list);
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater)
                    context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.adapter_top10, null);
        }
        final Top item = list.get(position);
        if (item != null) {
            tv_TenSach = view.findViewById(R.id.tv_TenSachTop10);
            tv_SoLuong = view.findViewById(R.id.tv_SoLuong);

            tv_TenSach.setText(item.getTenSach());
            tv_SoLuong.setText(String.valueOf(item.getSoLuong()));
        }
        return view;
    }
}
