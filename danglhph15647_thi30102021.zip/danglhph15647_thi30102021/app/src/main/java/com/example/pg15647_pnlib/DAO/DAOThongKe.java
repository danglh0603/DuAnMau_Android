package com.example.pg15647_pnlib.DAO;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.pg15647_pnlib.DTO.Sach;
import com.example.pg15647_pnlib.DTO.Top;
import com.example.pg15647_pnlib.Database.DatabaseLib;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class DAOThongKe {
    SQLiteDatabase db;
    DatabaseLib databaseLib;
    Context context;
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

    public DAOThongKe(Context context) {
        this.context = context;
        databaseLib = new DatabaseLib(context);
        db = databaseLib.getWritableDatabase();
    }

    // thong ke
    public ArrayList<Top> getTop10() {
        String sqlTop = "SELECT maSach, count(maSach) as soLuong FROM phieuMuon GROUP BY maSach ORDER BY soLuong DESC LIMIT 10";
        ArrayList<Top> list = new ArrayList<>();
        DAOSach daoSach = new DAOSach(context);
        Cursor cursor = db.rawQuery(sqlTop, null);
        while (cursor.moveToNext()) {
            Top top = new Top();
            Sach sach = daoSach.getID(cursor.getString(cursor.getColumnIndex("maSach")));
            top.setTenSach(sach.getTenSach());
            top.setSoLuong(Integer.parseInt(cursor.getString(cursor.getColumnIndex("soLuong"))));
            list.add(top);
        }
        return list;
    }

    // doanh thu
    public int getDoanhThu(String tuNgay, String denNgay) {
        String sqlDoanhThu = "SELECT SUM(tienThue) as doanhThu FROM phieuMuon WHERE ngay BETWEEN ? AND ?";
        ArrayList<Integer> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sqlDoanhThu, new String[]{tuNgay, denNgay});
        while (cursor.moveToNext()) {
            try {
                list.add(Integer.parseInt(cursor.getString(cursor.getColumnIndex("doanhThu"))));
            } catch (Exception e) {
                list.add(0);
            }
        }
        return list.get(0);
    }
}
