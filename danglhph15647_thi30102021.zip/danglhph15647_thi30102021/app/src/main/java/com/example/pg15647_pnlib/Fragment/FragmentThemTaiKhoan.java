package com.example.pg15647_pnlib.Fragment;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pg15647_pnlib.Adapter.AdapterThemThuThu;
import com.example.pg15647_pnlib.DAO.DAOThuThu;
import com.example.pg15647_pnlib.DTO.ThuThu;
import com.example.pg15647_pnlib.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class FragmentThemTaiKhoan extends Fragment {

    private RecyclerView rcvThuThu;
    private FloatingActionButton fab;

    private EditText edMaTT;
    private EditText edTenTT;
    private EditText edMKTT;
    private EditText edReMKTT;
    private Button btnThem;
    private Button btnHuy;


    static DAOThuThu daoThuThu;
    ThuThu thuThu;
    AdapterThemThuThu adapterThemThuThu;
    ArrayList<ThuThu> list;

    public FragmentThemTaiKhoan() {
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @org.jetbrains.annotations.NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_themtaikhoan, container, false);
        rcvThuThu = view.findViewById(R.id.rcv_ThuThu);
        list = new ArrayList<>();
        daoThuThu = new DAOThuThu(getActivity());
        fab = view.findViewById(R.id.fab);
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        rcvThuThu.setLayoutManager(manager);
        capnhatLv();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
        return view;
    }

    protected void openDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_them_tk, null);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
        //anh xa
        edMaTT = view.findViewById(R.id.ed_MaTT);
        edTenTT = view.findViewById(R.id.ed_TenTT);
        edMKTT = view.findViewById(R.id.ed_MKTT);
        edReMKTT = view.findViewById(R.id.ed_ReMKTT);
        btnThem = view.findViewById(R.id.btn_Them);
        btnHuy = view.findViewById(R.id.btn_Huy);


        btnHuy.setOnClickListener(v -> alertDialog.dismiss());

        btnThem.setOnClickListener(v -> {
            if (validate() > 0) {
                ThuThu thuThu = new ThuThu();
                thuThu.setMaTT(edMaTT.getText().toString());
                thuThu.setHoTen(edTenTT.getText().toString());
                thuThu.setMatKhau(edMKTT.getText().toString());
                //insert
                if (daoThuThu.insert(thuThu) > 0) {
                    Toast.makeText(getContext(), "Thêm thành công!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Thêm thất bại!", Toast.LENGTH_SHORT).show();
                }
                capnhatLv();
                alertDialog.dismiss();
            }
        });


    }

    private void capnhatLv() {
        list = daoThuThu.getAll();
        adapterThemThuThu = new AdapterThemThuThu(getActivity(), this, list);
        rcvThuThu.setAdapter(adapterThemThuThu);
    }

    public void xoa(final String maTT) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_xoa, null);
        builder.setView(view);

        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();
        Button xoa = view.findViewById(R.id.btn_dialog_xoaTV);
        Button huy = view.findViewById(R.id.btn_dialog_huyTV);

        xoa.setOnClickListener(v -> {
            if (daoThuThu.delete(maTT) > 0) {
                capnhatLv();
                alertDialog.dismiss();
                Toast.makeText(getContext(), "Đã xóa", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Xóa thất bại!", Toast.LENGTH_SHORT).show();
            }
        });
        huy.setOnClickListener(v -> {
            alertDialog.dismiss();
            Toast.makeText(getContext(), "Đã hủy", Toast.LENGTH_SHORT).show();
        });

    }

    public int validate() {
        int check = 1;
        if (edMaTT.getText().toString().length() == 0 ||
                edTenTT.getText().toString().length() == 0 ||
                edMKTT.getText().toString().length() == 0) {
            Toast.makeText(getContext(), "Không để trống các trường!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (edMKTT.getText().toString().length() < 4) {
            Toast.makeText(getContext(), "Mật khẩu tối thiểu 4 kí tự!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (!edReMKTT.getText().toString().equals(edMKTT.getText().toString())) {
            Toast.makeText(getContext(), "Mật khẩu nhập lại không trùng!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        String tenDn = edMaTT.getText().toString();
        if (daoThuThu.checkUser(tenDn) == true) {
            Log.e("zzzzzzzzzzzzzz", "validate: " + tenDn);
            Toast.makeText(getContext(), "Tên đăng nhập đã tồn tại!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        return check;
    }

}
