package com.example.pg15647_pnlib.Fragment;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pg15647_pnlib.Adapter.AdapterSach;
import com.example.pg15647_pnlib.Adapter.AdapterSpinnerLoaiSach;
import com.example.pg15647_pnlib.DAO.DAOLoaiSach;
import com.example.pg15647_pnlib.DAO.DAOSach;
import com.example.pg15647_pnlib.DTO.LoaiSach;
import com.example.pg15647_pnlib.DTO.Sach;
import com.example.pg15647_pnlib.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class FragmentSach extends Fragment {
    RecyclerView rcv;
    ArrayList<Sach> lstSach;
    FloatingActionButton fab;
    EditText edMaSach, edTenSach, edGiaThue;
    EditText edSoTrang;

    Spinner spinner;
    Button btnLuu, btnHuy;
    static DAOSach daoSach;
    AdapterSach adapterSach;
    Sach sach;
    AdapterSpinnerLoaiSach adapterSpinnerLoaiSach;
    ArrayList<LoaiSach> lstLoaiSach;
    DAOLoaiSach daoLoaiSach;
    LoaiSach loaiSach;
    int maLoaiSach, position;

    private EditText edSearch;
    private Button btnSearch;


    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @org.jetbrains.annotations.NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sach, container, false);
        rcv = view.findViewById(R.id.rcv_Sach);
        fab = view.findViewById(R.id.fab_add_Sach);
        edSearch = view.findViewById(R.id.edSearch);
        btnSearch = view.findViewById(R.id.btnSearch);

        daoSach = new DAOSach(getActivity());

        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        rcv.setLayoutManager(manager);

        //cap nhat lv
        capNhatLv();


        btnSearch.setOnClickListener(v -> {
            if (edSearch.getText().toString().length() != 0) {
                lstSach = daoSach.getSearch(edSearch.getText().toString());
                if (lstSach != null) {
                    Toast.makeText(getContext(), "Tim thay " + lstSach.size() + " ket qua!", Toast.LENGTH_SHORT).show();
                    adapterSach = new AdapterSach(getContext(), this, lstSach);
                    rcv.setAdapter(adapterSach);
                } else {
                    Toast.makeText(getContext(), "K tim thay" + "\n" + "Da refresh lai list!", Toast.LENGTH_SHORT).show();
                    capNhatLv();
                }
            } else {
                capNhatLv();
            }

        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(getContext(), 0);
            }
        });

        return view;
    }

    protected void openDialog(final Context context, final int type) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_sach, null);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));


        edMaSach = view.findViewById(R.id.ed_dialogMaSach);
        edTenSach = view.findViewById(R.id.ed_dialogTenSach);
        edSoTrang = view.findViewById(R.id.ed_dialogSoTrang);
        edGiaThue = view.findViewById(R.id.ed_dialogGiaThue);
        spinner = view.findViewById(R.id.spn_dialogLoaiSach);
        btnLuu = view.findViewById(R.id.btn_dialogLuuSach);
        btnHuy = view.findViewById(R.id.btn_dialogHuySach);

        // setAdapter cho spinner
        lstLoaiSach = new ArrayList<>();
        daoLoaiSach = new DAOLoaiSach(context);
        lstLoaiSach = daoLoaiSach.getAll();
        adapterSpinnerLoaiSach = new AdapterSpinnerLoaiSach(context, lstLoaiSach);
        spinner.setAdapter(adapterSpinnerLoaiSach);
        // lấy mã sach
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                maLoaiSach = lstLoaiSach.get(position).getMaLoai();
                //Toast.makeText(context, "Chon " + lstLoaiSach.get(position).tenLoaiSach, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // kiểm tra insert hay update
        if (type != 0) {
            edMaSach.setText(String.valueOf(sach.getMaSach()));
            edTenSach.setText(sach.getTenSach());
            edSoTrang.setText(String.valueOf(sach.getSoTrang()));
            edGiaThue.setText(String.valueOf(sach.getGiaThue()));
            for (int i = 0; i < lstLoaiSach.size(); i++) {
                if (sach.getMaLoai() == (lstLoaiSach.get(i).getMaLoai())) {
                    position = i;
                }
                Log.e("position", "openDialog: " + position);
                spinner.setSelection(position);
            }
        }

        btnHuy.setOnClickListener(v -> {
            alertDialog.dismiss();
        });

        btnLuu.setOnClickListener(v -> {
            if (validate() > 0) {
                sach = new Sach();
                sach.setTenSach(edTenSach.getText().toString());
                sach.setSoTrang(Integer.parseInt(edSoTrang.getText().toString()));
                sach.setGiaThue(Integer.parseInt(edGiaThue.getText().toString()));
                sach.setMaLoai(maLoaiSach);

                if (type == 0) {
                    // type == 0: insert
                    if (daoSach.insert(sach) > 0) {
                        Toast.makeText(context, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Thêm thất bại", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // type == 1: update
                    sach.setMaSach(Integer.parseInt(edMaSach.getText().toString()));
                    if (daoSach.update(sach) > 0) {
                        Toast.makeText(context, "Update thành công!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Update thất bại!", Toast.LENGTH_SHORT).show();
                    }
                }
                capNhatLv();
                alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }


    public void xoa(final int id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_xoa, null);
        builder.setView(view);

        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        Button xoa = view.findViewById(R.id.btn_dialog_xoaTV);
        Button huy = view.findViewById(R.id.btn_dialog_huyTV);

        xoa.setOnClickListener(v -> {
            if (daoSach.delete(id) > 0) {
                capNhatLv();
                alertDialog.dismiss();
                Toast.makeText(getContext(), "Đã xóa", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Xóa thất bại!", Toast.LENGTH_SHORT).show();
            }
        });
        huy.setOnClickListener(v -> {
            alertDialog.dismiss();
            Toast.makeText(getContext(), "Đã hủy", Toast.LENGTH_SHORT).show();
        });

        alertDialog.show();
    }

    void capNhatLv() {
        lstSach = daoSach.getAll();
        adapterSach = new AdapterSach(getContext(), this, lstSach);
        rcv.setAdapter(adapterSach);
    }

    public void update(int position) {
        sach = lstSach.get(position);
        openDialog(getContext(), 1);
    }

    public int validate() {
        int check = 1;
        if (edTenSach.getText().toString().length() == 0 ||
                edGiaThue.getText().toString().length() == 0) {
            Toast.makeText(getContext(), "Không để trống các trường!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (edTenSach.getText().toString().length() < 3) {
            Toast.makeText(getContext(), "Tên loại sách tối thiểu 3 kí tự!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (lstLoaiSach.size() == 0) {
            Toast.makeText(getContext(), "Loại sách đang trống!" + "\n" + "Tạo loại sách trước!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        return check;
    }
}

