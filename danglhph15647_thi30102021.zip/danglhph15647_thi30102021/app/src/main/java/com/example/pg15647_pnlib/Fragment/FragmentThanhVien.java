package com.example.pg15647_pnlib.Fragment;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pg15647_pnlib.Adapter.AdapterThanhVien;
import com.example.pg15647_pnlib.DAO.DAOThanhVien;
import com.example.pg15647_pnlib.DTO.Thanhvien;
import com.example.pg15647_pnlib.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class FragmentThanhVien extends Fragment {

    RecyclerView rcv;
    ArrayList<Thanhvien> list;
    FloatingActionButton fab;
    EditText edMaTV, edTenTV, edNamSinh;
    Button btnLuu, btnHuy;

    static DAOThanhVien daoThanhVien;
    AdapterThanhVien adapterThanhVien;
    Thanhvien thanhvien;

    public FragmentThanhVien() {
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @org.jetbrains.annotations.NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_thanhvien, container, false);

        rcv = view.findViewById(R.id.rcvThanhVien);
        fab = view.findViewById(R.id.fl_add_ThanhVien);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(getContext(), 0);
            }
        });
        list = new ArrayList<>();
        daoThanhVien = new DAOThanhVien(getActivity());

        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        rcv.setLayoutManager(manager);

        capNhatLv();

        return view;
    }

    protected void openDialog(final Context context, final int type) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_thanhvien, null);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
        // anh xa
        edTenTV = view.findViewById(R.id.ed_dialogTenThanhVien);
        edMaTV = view.findViewById(R.id.ed_dialogMaThanhVien);
        edNamSinh = view.findViewById(R.id.ed_dialogNamSinhThanhVien);
        btnLuu = view.findViewById(R.id.btn_dialogLuuTV);
        btnHuy = view.findViewById(R.id.btn_dialogHuyTV);

        // kiểm tra insert hay update
        if (type != 0) {
            edMaTV.setText(String.valueOf(thanhvien.getMaTV()));
            edTenTV.setText(thanhvien.getHoTen());
            edNamSinh.setText(String.valueOf(thanhvien.getNamSinh()));
        }
        btnHuy.setOnClickListener(v -> {
            alertDialog.dismiss();
        });

        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate() > 0) {
                    thanhvien = new Thanhvien();
                    thanhvien.setHoTen(edTenTV.getText().toString());
                    thanhvien.setNamSinh(Integer.parseInt(edNamSinh.getText().toString()));

                    if (type == 0) {
                        // type == 0: insert
                        if (daoThanhVien.insert(thanhvien) > 0) {
                            Toast.makeText(context, "Thêm thành công", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Thêm thất bại", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // type == 1: update
                        thanhvien.setMaTV(Integer.parseInt(edMaTV.getText().toString()));
                        if (daoThanhVien.update(thanhvien) > 0) {
                            Toast.makeText(context, "Update thành công!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Update thất bại!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    capNhatLv();
                    alertDialog.dismiss();
                }
            }
        });
    }

    public void xoa(final int id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_xoa, null);
        builder.setView(view);

        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();
        Button xoa = view.findViewById(R.id.btn_dialog_xoaTV);
        Button huy = view.findViewById(R.id.btn_dialog_huyTV);

        xoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (daoThanhVien.delete(id) > 0) {
                    capNhatLv();
                    alertDialog.dismiss();
                    Toast.makeText(getContext(), "Đã xóa", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Xóa thất bại!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        huy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                Toast.makeText(getContext(), "Đã hủy", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void update(final int position) {
        thanhvien = list.get(position);
        openDialog(getContext(), 1);
    }

    void capNhatLv() {
        list = daoThanhVien.getAll();
        adapterThanhVien = new AdapterThanhVien(getContext(), this, list);
        rcv.setAdapter(adapterThanhVien);

    }


    public int validate() {
        int check = 1;
        if (edTenTV.getText().toString().length() == 0 ||
                edNamSinh.getText().toString().length() == 0) {
            Toast.makeText(getContext(), "Không để trống các trường!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (edTenTV.getText().toString().length() < 2) {
            Toast.makeText(getContext(), "Không để trống các trường!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        return check;
    }
}
