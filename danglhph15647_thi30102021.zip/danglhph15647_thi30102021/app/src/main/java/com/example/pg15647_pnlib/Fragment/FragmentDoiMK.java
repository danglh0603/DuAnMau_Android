package com.example.pg15647_pnlib.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.pg15647_pnlib.DAO.DAOThuThu;
import com.example.pg15647_pnlib.DTO.ThuThu;
import com.example.pg15647_pnlib.R;

public class FragmentDoiMK extends Fragment {
    EditText  edOldPass, edNewPass, edRePass;
    Button btnUpdate;
    DAOThuThu daoThuThu;
    ThuThu thuThu;

    public FragmentDoiMK() {
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @org.jetbrains.annotations.NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_doimk, container, false);
        edOldPass = view.findViewById(R.id.ed_oldMK);
        edNewPass = view.findViewById(R.id.ed_newMK);
        edRePass = view.findViewById(R.id.ed_ReMK);
        btnUpdate = view.findViewById(R.id.btn_Update);

        daoThuThu = new DAOThuThu(getContext());
        thuThu = new ThuThu();

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences preferences = getActivity().getSharedPreferences("Accout_file", Context.MODE_PRIVATE);
                String user = preferences.getString("USER", "");
                if (validate() > 0) {
                    thuThu = daoThuThu.getID(user);
                    thuThu.setMatKhau(edNewPass.getText().toString());
                    daoThuThu.update(thuThu);
                    if (daoThuThu.update(thuThu) > 0) {
                        Toast.makeText(getContext(), "Thay đổi mật khẩu thành công!", Toast.LENGTH_SHORT).show();
                        edNewPass.setText("");
                        edOldPass.setText("");
                        edRePass.setText("");
                    } else {
                        Toast.makeText(getContext(), "Thay đổi không thành công!", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        return view;
    }

    private int validate() {
        int check = 1;
        if (edRePass.getText().toString().length() == 0 ||
                edNewPass.getText().toString().length() == 0 ||
                edOldPass.getText().toString().length() == 0
        ) {
            check = -1;
            Toast.makeText(getContext(), "Không để trống các trường!", Toast.LENGTH_SHORT).show();
            return check;
        } else {
            // doc user, pass trong sharedPreferences
            SharedPreferences preferences = getActivity().getSharedPreferences("Accout_file", Context.MODE_PRIVATE);
            String oldPass = preferences.getString("PASS", "");
            String newpass = edNewPass.getText().toString();
            String rePass = edRePass.getText().toString();
            if (!oldPass.equals(edOldPass.getText().toString())) {
                Toast.makeText(getContext(), "Mật khẩu cũ không chính xác!", Toast.LENGTH_SHORT).show();
                check = -1;
                return check;
            }

            if (!newpass.equals(rePass)) {
                Toast.makeText(getContext(), "Nhập lại mật khẩu không trùng!", Toast.LENGTH_SHORT).show();
                check = -1;
                return check;
            }
            if (edRePass.getText().toString().length() < 4 ||
                    edNewPass.getText().toString().length() < 4) {
                check = -1;
                Toast.makeText(getContext(), "Mật khẩu tối thiểu 4 kí tự!", Toast.LENGTH_SHORT).show();
                return check;
            }
        }

        return check;
    }
}
