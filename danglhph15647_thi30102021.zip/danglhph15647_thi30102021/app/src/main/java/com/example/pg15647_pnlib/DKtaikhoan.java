package com.example.pg15647_pnlib;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pg15647_pnlib.DAO.DAOThuThu;
import com.example.pg15647_pnlib.DTO.ThuThu;

public class DKtaikhoan extends AppCompatActivity {


    private TextView textView;
    private EditText edMaTT;
    private TextView textView3;
    private EditText edTenTT;
    private TextView textView4;
    private EditText edMKTT;
    private TextView textView5;
    private EditText edReMKTT;
    private Button btnThem;
    private Button btnHuy;
    DAOThuThu daoThuThu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dktaikhoan);
        textView = findViewById(R.id.textView);
        edMaTT = findViewById(R.id.ed_MaTT);
        textView3 = findViewById(R.id.textView3);
        edTenTT = findViewById(R.id.ed_TenTT);
        textView4 = findViewById(R.id.textView4);
        edMKTT = findViewById(R.id.ed_MKTT);
        textView5 = findViewById(R.id.textView5);
        edReMKTT = findViewById(R.id.ed_ReMKTT);
        btnThem = findViewById(R.id.btn_Them);
        btnHuy = findViewById(R.id.btn_Huy);

        daoThuThu = new DAOThuThu(getApplicationContext());
        btnThem.setOnClickListener(v -> {
            if (validate() > 0) {
                ThuThu thuThu = new ThuThu();
                thuThu.setMaTT(edMaTT.getText().toString());
                thuThu.setHoTen(edTenTT.getText().toString());
                thuThu.setMatKhau(edMKTT.getText().toString());
                //insert
                if (daoThuThu.insert(thuThu) > 0) {
                    Toast.makeText(getApplicationContext(), "Đăng kí thành công!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(DKtaikhoan.this, Main.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Đăng kí thất bại!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public int validate() {
        int check = 1;
        if (edMaTT.getText().toString().length() == 0 ||
                edTenTT.getText().toString().length() == 0 ||
                edMKTT.getText().toString().length() == 0) {
            Toast.makeText(getApplicationContext(), "Không để trống các trường!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (edMKTT.getText().toString().length() < 4) {
            Toast.makeText(getApplicationContext(), "Mật khẩu tối thiểu 4 kí tự!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (!edReMKTT.getText().toString().equals(edMKTT.getText().toString())) {
            Toast.makeText(getApplicationContext(), "Mật khẩu nhập lại không chính xác!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        String tenDn = edMaTT.getText().toString();
        if (daoThuThu.checkUser(tenDn) == true) {
            //Log.e("zzzzzzzzzzzzzz", "validate: " + tenDn);
            Toast.makeText(getApplicationContext(), "Tên đăng nhập đã tồn tại!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        return check;
    }

    public void huy() {
        AlertDialog.Builder builder = new AlertDialog.Builder(DKtaikhoan.this);
        View view1 = LayoutInflater.from(DKtaikhoan.this).inflate(R.layout.dialog_thoat, null);
        builder.setView(view1);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();

        Button btn_thoat = view1.findViewById(R.id.btn_Thoat);
        Button btn_huy = view1.findViewById(R.id.btn_Huy);
        btn_thoat.setOnClickListener(v -> {
            alertDialog.dismiss();
            System.exit(0);

        });

        btn_huy.setOnClickListener(v -> alertDialog.dismiss());
    }

    @Override
    public void onBackPressed() {
        huy();
    }
}