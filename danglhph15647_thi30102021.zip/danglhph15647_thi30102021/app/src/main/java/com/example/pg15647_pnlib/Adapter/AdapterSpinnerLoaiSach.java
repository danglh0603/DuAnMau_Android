package com.example.pg15647_pnlib.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.pg15647_pnlib.DTO.LoaiSach;
import com.example.pg15647_pnlib.R;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class AdapterSpinnerLoaiSach extends ArrayAdapter<LoaiSach> {
    private Context context;
    private List<LoaiSach> lstLoaiSach;
    TextView tvMaLoaiSach, tvTenLoaiSach;


    public AdapterSpinnerLoaiSach(@NonNull Context context, List<LoaiSach> lstLoaiSach) {
        super(context, 0, lstLoaiSach);
        this.context = context;
        this.lstLoaiSach = lstLoaiSach;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater =
                    (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.adapter_spinner_loaisach, null);
        }
        final LoaiSach loaiSach = lstLoaiSach.get(position);
        if (loaiSach != null) {
            tvMaLoaiSach = view.findViewById(R.id.tv_spinner_maLoaiSach);
            tvTenLoaiSach = view.findViewById(R.id.tv_spinner_tenLoaiSach);
            tvMaLoaiSach.setText(loaiSach.getMaLoai()+".");
            tvTenLoaiSach.setText(loaiSach.getTenLoaiSach());
        }

        return view;
    }

    @Override
    public View getDropDownView(int position, @Nullable @org.jetbrains.annotations.Nullable View convertView, @NonNull @NotNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater
                    = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.adapter_drop_spinner_loaisach, null);
        }
        final LoaiSach loaiSach = lstLoaiSach.get(position);
        if (loaiSach != null) {
            tvMaLoaiSach = view.findViewById(R.id.tv_spinner_maLoaiSach);
            tvTenLoaiSach = view.findViewById(R.id.tv_spinner_tenLoaiSach);
            tvMaLoaiSach.setText(loaiSach.getMaLoai()+".");
            tvTenLoaiSach.setText(loaiSach.getTenLoaiSach());
        }
        return view;
    }
}
