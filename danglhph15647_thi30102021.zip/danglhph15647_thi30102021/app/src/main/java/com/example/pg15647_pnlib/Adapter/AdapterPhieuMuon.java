package com.example.pg15647_pnlib.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pg15647_pnlib.DAO.DAOSach;
import com.example.pg15647_pnlib.DAO.DAOThanhVien;
import com.example.pg15647_pnlib.DTO.PhieuMuon;
import com.example.pg15647_pnlib.DTO.Sach;
import com.example.pg15647_pnlib.DTO.Thanhvien;
import com.example.pg15647_pnlib.Fragment.FragmentPhieuMuon;
import com.example.pg15647_pnlib.R;

import org.jetbrains.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class AdapterPhieuMuon extends RecyclerView.Adapter<AdapterPhieuMuon.ViewHolder> {
    private Context context;
    FragmentPhieuMuon fragmentPhieuMuon;
    private ArrayList<PhieuMuon> list;
    DAOSach daoSach;
    DAOThanhVien daoThanhVien;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public AdapterPhieuMuon(Context context, FragmentPhieuMuon fragmentPhieuMuon, ArrayList<PhieuMuon> list) {
        this.context = context;
        this.fragmentPhieuMuon = fragmentPhieuMuon;
        this.list = list;

    }

    @NonNull
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_phieumuon, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final PhieuMuon phieuMuon = list.get(position);
        if (phieuMuon != null) {
            holder.tvMaPM.setText("Mã phiếu mượn: " + phieuMuon.getMaPM());

            daoSach = new DAOSach(context);
            Sach sach = daoSach.getID(String.valueOf(phieuMuon.getMaSach()));
            holder.tvTenSachPM.setText(sach.getTenSach());

            daoThanhVien = new DAOThanhVien(context);
            Thanhvien thanhvien = daoThanhVien.getID(String.valueOf(phieuMuon.getMaTV()));
            holder.tvTenThanhVienPM.setText(thanhvien.getHoTen());

            holder.tvGiaThuehPM.setText(phieuMuon.getTienThue() + " VNĐ");
            holder.tvNgayThue.setText(sdf.format(phieuMuon.getNgay()));
            if (phieuMuon.getTraSach() == 0) {
                holder.tvTraSachPM.setText("Chưa trả sách");
                holder.tvTraSachPM.setTextColor(Color.RED);
            } else {
                holder.tvTraSachPM.setText("Đã trả sách");
                holder.tvTraSachPM.setTextColor(Color.BLUE);
            }
            // update
            holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    fragmentPhieuMuon.update(position);
                    return false;
                }
            });
            //xóa
            holder.btnXoaPM.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fragmentPhieuMuon.xoa(String.valueOf(phieuMuon.getMaPM()));
                }
            });
        }

    }

    @Override
    public int getItemCount() {

        if (list != null) {
            return list.size();
        }

        return 0;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvMaPM;
        TextView tvTenThanhVienPM;
        TextView tvTenSachPM;
        TextView tvGiaThuehPM;
        TextView tvTraSachPM;
        TextView tvNgayThue;
        Button btnXoaPM;

        public ViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.adapterCardView);
            tvMaPM = itemView.findViewById(R.id.tv_maPM);
            tvTenThanhVienPM = itemView.findViewById(R.id.tv_tenThanhVienPM);
            tvTenSachPM = itemView.findViewById(R.id.tv_tenSachPM);
            tvGiaThuehPM = itemView.findViewById(R.id.tv_giaThuehPM);
            tvTraSachPM = itemView.findViewById(R.id.tv_traSachPM);
            tvNgayThue = itemView.findViewById(R.id.tv_ngayThue);
            btnXoaPM = itemView.findViewById(R.id.btn_xoaPM);
        }
    }
}
