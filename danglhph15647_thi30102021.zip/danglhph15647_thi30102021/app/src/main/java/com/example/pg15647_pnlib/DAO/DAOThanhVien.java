package com.example.pg15647_pnlib.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.pg15647_pnlib.DTO.Thanhvien;
import com.example.pg15647_pnlib.Database.DatabaseLib;

import java.util.ArrayList;


public class DAOThanhVien {
    private DatabaseLib databaseLib;
    private SQLiteDatabase db;

    public DAOThanhVien(Context context) {
        databaseLib = new DatabaseLib(context);
        db = databaseLib.getWritableDatabase();
    }

    public long insert(Thanhvien thanhvien) {
        ContentValues values = new ContentValues();
        values.put("hoTen", thanhvien.getHoTen());
        values.put("namSinh", thanhvien.getNamSinh());
        return db.insert("thanhVien", null, values);
    }

    public int update(Thanhvien thanhvien) {
        ContentValues values = new ContentValues();
        values.put("hoTen", thanhvien.getHoTen());
        values.put("namSinh", thanhvien.getNamSinh());
        return db.update("thanhVien", values, "maTV=?", new String[]{String.valueOf(thanhvien.getMaTV())});
    }

    public int delete(int id) {
        return db.delete("thanhVien", "maTV = ?", new String[]{String.valueOf(id)});
    }

    // getAll
    public ArrayList<Thanhvien> getAll() {
        String sql = "SELECT*FROM thanhVien";
        return getData(sql);
    }

    public Thanhvien getID(String id) {
        String sql = "SELECT* FROM thanhVien WHERE maTV=?";
        Thanhvien thanhvien = new Thanhvien();
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        if (cursor.moveToFirst()) {
            thanhvien.setMaTV(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maTV"))));
            thanhvien.setHoTen(cursor.getString(cursor.getColumnIndex("hoTen")));
            thanhvien.setNamSinh(cursor.getInt(cursor.getColumnIndex("namSinh")));
        }
        return thanhvien;
    }

    private ArrayList<Thanhvien> getData(String sql, String... selectionArgs) {
        ArrayList<Thanhvien> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, selectionArgs);
        while (cursor.moveToNext()) {
            Thanhvien thanhvien = new Thanhvien();
            thanhvien.setMaTV(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maTV"))));
            thanhvien.setHoTen(cursor.getString(cursor.getColumnIndex("hoTen")));
            thanhvien.setNamSinh(cursor.getInt(cursor.getColumnIndex("namSinh")));
            list.add(thanhvien);
        }

        return list;

    }

}
