package com.example.pnlib.DTO;

public class LoaiSach {
    public int maLoai;
    public String tenLoaiSach;

    public int getMaLoai() {
        return maLoai;
    }

    public void setMaLoai(int maLoai) {
        this.maLoai = maLoai;
    }

    public String getTenLoaiSach() {
        return tenLoaiSach;
    }

    public void setTenLoaiSach(String tenLoaiSach) {
        this.tenLoaiSach = tenLoaiSach;
    }

    public LoaiSach(int maLoai, String tenLoaiSach) {
        this.maLoai = maLoai;
        this.tenLoaiSach = tenLoaiSach;
    }

    public LoaiSach() {
    }
}
