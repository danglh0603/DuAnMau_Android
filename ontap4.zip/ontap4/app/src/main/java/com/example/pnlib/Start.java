package com.example.pnlib;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Start extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        findViewById(R.id.imageView).setOnClickListener(v -> {
            Intent in = new Intent(Start.this, Main.class);
            startActivity(in);
        });
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                Intent in = new Intent(Start.this,Login.class);
//                startActivity(in);
//                finish();
//            }
//        },2000);
    }
}