package com.example.pnlib;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;

import com.example.pnlib.Fragment.FragmentDoanhThu;
import com.example.pnlib.Fragment.FragmentDoiMK;
import com.example.pnlib.Fragment.FragmentLoaiSach;
import com.example.pnlib.Fragment.FragmentPhieuMuon;
import com.example.pnlib.Fragment.FragmentSach;
import com.example.pnlib.Fragment.FragmentThanhVien;
import com.example.pnlib.Fragment.FragmentThemTaiKhoan;
import com.example.pnlib.Fragment.FragmentTop10;
import com.google.android.material.navigation.NavigationView;

import org.jetbrains.annotations.NotNull;

public class Main extends AppCompatActivity {
    Toolbar toolbar;
    ActionBar actionBar;
    DrawerLayout drawerLayout;
    FragmentContainerView fragmentContainerView;
    FragmentManager fm;
    NavigationView navigationView;
    TextView tvHeaderName;

    FragmentPhieuMuon fragmentPhieuMuon;
    FragmentLoaiSach fragmentLoaiSach;
    FragmentSach fragmentSach;
    FragmentThanhVien fragmentThanhVien;
    FragmentTop10 fragmentTop10;
    FragmentDoanhThu fragmentDoanhThu;
    FragmentDoiMK fragmentDoiMK;
    FragmentThemTaiKhoan fragmentThemTaiKhoan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // anh xa
        drawerLayout = findViewById(R.id.dr);
        toolbar = findViewById(R.id.toolbar);
        fragmentContainerView = findViewById(R.id.frag_container);
        navigationView = findViewById(R.id.nav_View);

        View headerView = navigationView.getHeaderView(0);
        tvHeaderName = headerView.findViewById(R.id.tv_headerName);

        // toolbar
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_menu_24);
        actionBar.setDisplayHomeAsUpEnabled(true);
        //khai bao Fragment
        ganFragment();

        // gán fragment phiếu mượn làm màn hình mặc định
        if (savedInstanceState == null) {
            fm.beginTransaction()
                    .replace(R.id.frag_container, fragmentPhieuMuon)
                    .commit();
            navigationView.setCheckedItem(R.id.nav_phieuMuon);
        }
        itemNav();
        // check user hay thuthu
//        Intent intent = getIntent();
//        String user = intent.getStringExtra("user");
//        tvHeaderName.setText("Xin chào " + user);
//        if (user.equals("admin")) {
//            navigationView.getMenu().findItem(R.id.nav_themThuThu).setVisible(true);
//        }


    }

    private void ganFragment() {
        fm = getSupportFragmentManager();
        fragmentPhieuMuon = new FragmentPhieuMuon();
        fragmentLoaiSach = new FragmentLoaiSach();
        fragmentSach = new FragmentSach();
        fragmentThanhVien = new FragmentThanhVien();
        fragmentThemTaiKhoan = new FragmentThemTaiKhoan();
        fragmentTop10 = new FragmentTop10();
        fragmentDoanhThu = new FragmentDoanhThu();
        fragmentDoiMK = new FragmentDoiMK();
    }

    private void itemNav() {
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull @NotNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_phieuMuon: {
                        actionBar.setTitle("Quản lí phiếu mượn");
                        fm.beginTransaction()
                                .replace(R.id.frag_container, fragmentPhieuMuon)
                                .commit();
                        navigationView.setCheckedItem(R.id.nav_phieuMuon);
                        break;
                    }
                    case R.id.nav_loaiSach: {
                        actionBar.setTitle("Quản lí loại sách");
                        fm.beginTransaction()
                                .replace(R.id.frag_container, fragmentLoaiSach)
                                .commit();
                        navigationView.setCheckedItem(R.id.nav_loaiSach);
                        break;
                    }
                    case R.id.nav_Sach: {
                        actionBar.setTitle("Quản lí sách");
                        fm.beginTransaction()
                                .replace(R.id.frag_container, fragmentSach)
                                .commit();
                        navigationView.setCheckedItem(R.id.nav_Sach);
                        break;
                    }
                    case R.id.nav_thanhVien: {
                        actionBar.setTitle("Quản lí thành viên");
                        fm.beginTransaction()
                                .replace(R.id.frag_container, fragmentThanhVien)
                                .commit();
                        navigationView.setCheckedItem(R.id.nav_thanhVien);
                        break;
                    }
                    case R.id.nav_themThuThu: {
                        actionBar.setTitle("Thêm tài khoản");
                        fm.beginTransaction()
                                .replace(R.id.frag_container, fragmentThemTaiKhoan)
                                .commit();
                        navigationView.setCheckedItem(R.id.nav_themThuThu);
                        break;
                    }
                    case R.id.nav_top10: {
                        actionBar.setTitle("Top 10 sách mượn nhiều nhất");
                        fm.beginTransaction()
                                .replace(R.id.frag_container, fragmentTop10)
                                .commit();
                        navigationView.setCheckedItem(R.id.nav_top10);
                        break;
                    }
                    case R.id.nav_doanhThu: {
                        actionBar.setTitle("Doanh thu");
                        fm.beginTransaction()
                                .replace(R.id.frag_container, fragmentDoanhThu)
                                .commit();
                        navigationView.setCheckedItem(R.id.nav_doanhThu);
                        break;
                    }
                    case R.id.nav_doiMK: {
                        actionBar.setTitle("Đổi mật khẩu");
                        fm.beginTransaction()
                                .replace(R.id.frag_container, fragmentDoiMK)
                                .commit();
                        navigationView.setCheckedItem(R.id.nav_doiMK);
                        break;
                    }
                    case R.id.nav_dangXuat: {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Main.this);
                        View view = LayoutInflater.from(Main.this).inflate(R.layout.dialog_dangxuat, null);
                        builder.setView(view);
                        AlertDialog alertDialog = builder.create();
                        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                        alertDialog.show();
                        //anh xa
                        Button btnDangxuat = view.findViewById(R.id.btn_DangXuatDX);
                        Button btnHuy = view.findViewById(R.id.btn_HuyDX);
                        //
                        btnHuy.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                alertDialog.dismiss();
                            }
                        });
                        btnDangxuat.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                alertDialog.dismiss();
                                Intent in = new Intent(Main.this, Login.class);
                                startActivity(in);
                                Toast.makeText(getApplicationContext(), "Bạn đã đăng xuất thành công!", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        });
                        break;
                    }
                    default: {
                        Toast.makeText(Main.this, "Nav menu", Toast.LENGTH_SHORT).show();
                    }
                }
                drawerLayout.closeDrawer(navigationView);
                return false;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            drawerLayout.openDrawer(GravityCompat.START);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }

    }


}