package com.example.pnlib.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pnlib.DAO.DAOLoaiSach;
import com.example.pnlib.DTO.LoaiSach;
import com.example.pnlib.DTO.Sach;
import com.example.pnlib.Fragment.FragmentSach;
import com.example.pnlib.R;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class AdapterSach extends RecyclerView.Adapter<AdapterSach.ViewHolder> {
    private Context context;
    FragmentSach fragmentSach;
    private List<Sach> lstSach;


    public AdapterSach(@NonNull Context context, FragmentSach fragmentSach, List<Sach> lstSach) {
        this.context = context;
        this.lstSach = lstSach;
        this.fragmentSach = fragmentSach;

    }

    @NonNull
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_sach, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull ViewHolder holder, int position) {
        final Sach sach = lstSach.get(position);
        if (sach != null) {
            DAOLoaiSach daoLoaiSach = new DAOLoaiSach(context);
            LoaiSach loaiSach = daoLoaiSach.getID(String.valueOf(sach.getMaLoai()));
            holder.tvMaSach.setText("Mã sách: " + sach.getMaSach());
            holder.tvTenSach.setText("Tên sách: " + sach.getTenSach());
            holder.tvGiaThue.setText("Giá thuê: " + sach.getGiaThue());
            holder.tvLoai.setText("Loại sách: " + loaiSach.tenLoaiSach);
            holder.btnXoa.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fragmentSach.xoa(sach.getMaSach());
                }
            });
            holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    fragmentSach.update(position);
                    return false;
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return lstSach.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvMaSach, tvTenSach, tvGiaThue, tvLoai;
        Button btnXoa;
        CardView cardView;

        public ViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.adapterCardView);
            tvMaSach = itemView.findViewById(R.id.tv_maSach);
            tvTenSach = itemView.findViewById(R.id.tv_tenSach);
            tvGiaThue = itemView.findViewById(R.id.tv_giaThueSach);
            tvLoai = itemView.findViewById(R.id.tv_loaiSach);
            btnXoa = itemView.findViewById(R.id.btn_xoaSach);


        }
    }
}

