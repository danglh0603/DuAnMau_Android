package com.example.pnlib.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pnlib.DTO.LoaiSach;
import com.example.pnlib.Fragment.FragmentLoaiSach;
import com.example.pnlib.R;

import java.util.ArrayList;

public class AdapterLoaiSach extends RecyclerView.Adapter<AdapterLoaiSach.ViewHolder> {
    private Context context;
    FragmentLoaiSach fragmentLoaiSach;
    private ArrayList<LoaiSach> list;

    public AdapterLoaiSach(Context context, FragmentLoaiSach fragmentLoaiSach, ArrayList<LoaiSach> list) {
        this.context = context;
        this.fragmentLoaiSach = fragmentLoaiSach;
        this.list = list;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_loaisach, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final LoaiSach loaiSach = list.get(position);
        if (loaiSach != null) {
            holder.tvMaLS.setText("Mã loại: " + loaiSach.getMaLoai());
            holder.tvTenLS.setText("Tên loại: " + loaiSach.getTenLoaiSach());
            holder.btnXoaLS.setOnClickListener(v -> fragmentLoaiSach.xoa(loaiSach.getMaLoai()));
            holder.adapterCardView.setOnLongClickListener(v -> {
                fragmentLoaiSach.update(position);
                return false;
            });
        }
    }


    @Override
    public int getItemCount() {
        if (list != null) {
            return list.size();
        }
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        CardView adapterCardView;
        TextView tvMaLS;
        TextView tvTenLS;
        Button btnXoaLS;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            adapterCardView = itemView.findViewById(R.id.adapterCardView);
            tvMaLS = itemView.findViewById(R.id.tv_maLS);
            tvTenLS = itemView.findViewById(R.id.tv_tenLS);
            btnXoaLS = itemView.findViewById(R.id.btn_xoaLS);

        }
    }
}
