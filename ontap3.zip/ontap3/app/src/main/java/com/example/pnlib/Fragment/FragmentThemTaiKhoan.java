package com.example.pnlib.Fragment;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.pnlib.DAO.DAOThuThu;
import com.example.pnlib.DTO.ThuThu;
import com.example.pnlib.R;

public class FragmentThemTaiKhoan extends Fragment {

    EditText edMaTT, edTenTT, edMKTT, edReMK;
    Button btnLuu;
    static DAOThuThu daoThuThu;
    ThuThu thuThu;


    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @org.jetbrains.annotations.NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_themtaikhoan, container, false);
        edMaTT = view.findViewById(R.id.ed_MaTT);
        edTenTT = view.findViewById(R.id.ed_TenTT);
        edMKTT = view.findViewById(R.id.ed_MKTT);
        edReMK = view.findViewById(R.id.ed_ReMKTT);
        btnLuu = view.findViewById(R.id.btn_LuuTT);

        thuThu = new ThuThu();
        daoThuThu = new DAOThuThu(getContext());
        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate() > 0) {
                    thuThu.setMaTT(edMaTT.getText().toString());
                    thuThu.setHoTen(edTenTT.getText().toString());
                    thuThu.setMatKhau(edMKTT.getText().toString());
                    if (daoThuThu.insert(thuThu) > 0) {
                        openDialog();
                        edTenTT.setText("");
                        edMKTT.setText("");
                        edMaTT.setText("");
                        edReMK.setText("");
//                        Toast.makeText(getContext(), "Thêm thành công", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        return view;
    }

    private void openDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_tt, null);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
        TextView textView = view.findViewById(R.id.tv_dialog_addSucessfully);
        Button btn = view.findViewById(R.id.btnOK);
        textView.setText("Tên thủ thư: " + thuThu.getHoTen() + "\n" +
                "Tên đăng nhập: " + thuThu.getMaTT() + "\n" +
                "Mật khẩu: " + thuThu.getMatKhau());
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
    }

    public int validate() {
        int check = 1;
        if (edMaTT.getText().toString().length() == 0 ||
                edTenTT.getText().toString().length() == 0 ||
                edMKTT.getText().toString().length() == 0) {
            Toast.makeText(getContext(), "Không để trống các trường!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (edMKTT.getText().toString().length() < 4) {
            Toast.makeText(getContext(), "Mật khẩu tối thiểu 4 kí tự!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (!edReMK.getText().toString().equals(edMKTT.getText().toString())) {
            Toast.makeText(getContext(), "Mật khẩu nhập lại không trùng!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        String tenDn = edMaTT.getText().toString();
        if (daoThuThu.checkUser(tenDn) == true) {
            Log.e("zzzzzzzzzzzzzz", "validate: " + tenDn);
            Toast.makeText(getContext(), "Tên đăng nhập đã tồn tại!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        return check;
    }

}
