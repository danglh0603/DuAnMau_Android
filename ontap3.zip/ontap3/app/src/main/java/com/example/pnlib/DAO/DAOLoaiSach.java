package com.example.pnlib.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.pnlib.DTO.LoaiSach;
import com.example.pnlib.Database.DatabaseLib;

import java.util.ArrayList;


public class DAOLoaiSach {
    private DatabaseLib databaseLib;
    private SQLiteDatabase db;

    public DAOLoaiSach(Context context) {
        databaseLib = new DatabaseLib(context);
        db = databaseLib.getWritableDatabase();

    }

    public long insert(LoaiSach loaiSach) {
        ContentValues values = new ContentValues();
        values.put("tenLoaiSach", loaiSach.getTenLoaiSach());
        return db.insert("loaiSach", null, values);
    }

    public int update(LoaiSach loaiSach) {
        ContentValues values = new ContentValues();
        values.put("tenLoaiSach", loaiSach.getTenLoaiSach());
        return db.update("loaiSach", values, "maLoai= ?", new String[]{String.valueOf(loaiSach.getMaLoai())});
    }

    public int delete(int id) {
        return db.delete("loaiSach", "maLoai = ?", new String[]{String.valueOf(id)});
    }

    // getAll
    public ArrayList<LoaiSach> getAll() {
        String getAll = "SELECT* FROM loaiSach";
        return getData(getAll);
    }

    public LoaiSach getID(String id) {
        String sql = "SELECT* FROM loaiSach WHERE maLoai= ?";
        LoaiSach loaiSach = new LoaiSach();
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        if (cursor.moveToFirst()) {
            loaiSach.setMaLoai(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maLoai"))));
            loaiSach.setTenLoaiSach(cursor.getString(cursor.getColumnIndex("tenLoaiSach")));
        }
        return loaiSach;
    }

    private ArrayList<LoaiSach> getData(String sql, String... args) {
        ArrayList<LoaiSach> lst = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, args);
        while (cursor.moveToNext()) {
            LoaiSach loaiSach = new LoaiSach();
            loaiSach.setMaLoai(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maLoai"))));
            loaiSach.setTenLoaiSach(cursor.getString(cursor.getColumnIndex("tenLoaiSach")));
            lst.add(loaiSach);
        }
        return lst;
    }

}
