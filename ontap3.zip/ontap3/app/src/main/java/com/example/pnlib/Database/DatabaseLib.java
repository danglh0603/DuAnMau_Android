package com.example.pnlib.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseLib extends SQLiteOpenHelper {
    public DatabaseLib(@Nullable Context context) {

        super(context, "DataLib3.db", null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableThuThu = "create table thuThu(" +
                "maTT TEXT PRIMARY KEY ," +
                "hoTen TEXT NOT NULL," +
                "matKhau TEXT NOT NULL)";
        db.execSQL(createTableThuThu);
        String setAdmin = "INSERT INTO thuThu VALUES('admin', 'admin', 'admin')";
        db.execSQL(setAdmin);

        String createTableThanhVien = "create table thanhVien(" +
                "maTV INTEGER PRIMARY KEY AUTOINCREMENT," +
                "hoTen TEXT NOT NULL," +
                "namSinh TEXT NOT NULL)";
        db.execSQL(createTableThanhVien);
        String createTableLoaiSach = "create table loaiSach(" +
                "maLoai INTEGER PRIMARY KEY AUTOINCREMENT," +
                "tenLoaiSach TEXT NOT NULL)";
        db.execSQL(createTableLoaiSach);
        String createTableSach = "create table Sach(" +
                "maSach INTEGER PRIMARY KEY AUTOINCREMENT," +
                "tenSach TEXT NOT NULL," +
                "giaThue INTEGER NOT NULL," +
                "khuyenMai INTEGER NOT NULL," +
                "maLoai INTEGER REFERENCES loaiSach(maLoai) NOT NULL) ";
        db.execSQL(createTableSach);


        String createTablePhieuMuon = "create table phieuMuon(" +
                "maPM INTEGER PRIMARY KEY AUTOINCREMENT," +
                "maTT TEXT REFERENCES thuThu(maTT) NOT NULL," +
                "maTV INTEGER REFERENCES thanhVien(maTV) NOT NULL," +
                "maSach INTEGER REFERENCES Sach(maSach)," +
                "ngay DATE NOT NULL," +
                "traSach INTEGER NOT NULL," +
                "tienThue INTEGER NOT NULL)";
        db.execSQL(createTablePhieuMuon);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS thuThu");
        db.execSQL("DROP TABLE IF EXISTS thanhVien");
        db.execSQL("DROP TABLE IF EXISTS loaiSach");
        db.execSQL("DROP TABLE IF EXISTS Sach");
        db.execSQL("DROP TABLE IF EXISTS phieuMuon");

        onCreate(db);

    }
}
