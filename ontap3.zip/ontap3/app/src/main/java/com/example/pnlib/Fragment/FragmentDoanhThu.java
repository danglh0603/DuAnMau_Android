package com.example.pnlib.Fragment;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.pnlib.DAO.DAOThongKe;
import com.example.pnlib.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class FragmentDoanhThu extends Fragment {
    Button btnStart, btnEnd, btnDoanhThu;
    EditText edStart, edEnd;
    TextView tvDoanhThu;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public FragmentDoanhThu() {
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @org.jetbrains.annotations.NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_doanhthu, container, false);

        edStart = view.findViewById(R.id.ed_NgayBatDau);
        edEnd = view.findViewById(R.id.ed_NgayKetThuc);
        btnStart = view.findViewById(R.id.btn_NgayBatDau);
        btnEnd = view.findViewById(R.id.btn_NgayKetThuc);
        tvDoanhThu = view.findViewById(R.id.tv_DoanhThu);
        btnDoanhThu = view.findViewById(R.id.btn_DoanhThu);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(System.currentTimeMillis());
                DatePickerDialog dialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                edStart.setText(year + "-" + (month + 1) + "-" + dayOfMonth);
                            }
                        }
                        , calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DATE));
                dialog.show();
            }
        });
        btnEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(System.currentTimeMillis());
                DatePickerDialog dialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                edEnd.setText(year + "-" + (month + 1) + "-" + dayOfMonth);
                            }
                        }
                        , calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DATE));
                dialog.show();
            }
        });

        btnDoanhThu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tuNgay = edStart.getText().toString();
                String denNgay = edEnd.getText().toString();
                DAOThongKe daoThongKe = new DAOThongKe(getActivity());
                tvDoanhThu.setText(daoThongKe.getDoanhThu(tuNgay, denNgay) + " VNĐ");
            }
        });
        return view;
    }
}
