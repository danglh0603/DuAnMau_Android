package com.example.pnlib.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pnlib.DTO.Thanhvien;
import com.example.pnlib.Fragment.FragmentThanhVien;
import com.example.pnlib.R;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class AdapterThanhVien extends RecyclerView.Adapter<AdapterThanhVien.ViewHolder> {
    private Context context;
    FragmentThanhVien fragmentThanhVien;
    private ArrayList<Thanhvien> list;


    public AdapterThanhVien(Context context, FragmentThanhVien fragmentThanhVien, ArrayList<Thanhvien> list) {
        this.context = context;
        this.fragmentThanhVien = fragmentThanhVien;
        this.list = list;
    }

    @NonNull
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_thanhvien, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final Thanhvien thanhvien = list.get(position);
        if (thanhvien != null) {
            if (position % 2 == 0) {
                holder.tvMaVT.setText("Mã thành viên: " + thanhvien.getMaTV());
                holder.tvMaVT.setTextColor(Color.RED);
                holder.tvTenTV.setText("Tên thành viên: " + thanhvien.getHoTen());
                holder.tvTenTV.setTextColor(Color.RED);
                holder.tvNamSinh.setText("Năm sinh: " + thanhvien.getNamSinh());
                holder.tvNamSinh.setTextColor(Color.RED);
            } else {
                holder.tvMaVT.setText("Mã thành viên: " + thanhvien.getMaTV());
                holder.tvMaVT.setTextColor(Color.GREEN);
                holder.tvTenTV.setText("Tên thành viên: " + thanhvien.getHoTen());
                holder.tvTenTV.setTextColor(Color.GREEN);
                holder.tvNamSinh.setText("Năm sinh: " + thanhvien.getNamSinh());
                holder.tvNamSinh.setTextColor(Color.GREEN);
            }

            holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    fragmentThanhVien.update(position);
                    return false;
                }
            });
            // xóa
            holder.btnXoa.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fragmentThanhVien.xoa(thanhvien.getMaTV());
                }
            });

        }
    }


    @Override
    public int getItemCount() {
        if (list.size() > 0) {
            return list.size();
        }
        return 0;
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvMaVT, tvTenTV, tvNamSinh;
        Button btnXoa;
        CardView cardView;

        public ViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.adapterCardView);
            tvMaVT = itemView.findViewById(R.id.tv_maTV);
            tvTenTV = itemView.findViewById(R.id.tv_tenTV);
            tvNamSinh = itemView.findViewById(R.id.tv_namSinhTV);
            btnXoa = itemView.findViewById(R.id.btn_xoaTV);
        }
    }
}
