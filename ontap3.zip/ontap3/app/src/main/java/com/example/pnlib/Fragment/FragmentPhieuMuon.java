package com.example.pnlib.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pnlib.Adapter.AdapterPhieuMuon;
import com.example.pnlib.Adapter.AdapterSpinnerSach;
import com.example.pnlib.Adapter.AdapterSpinnerThanhVien;
import com.example.pnlib.DAO.DAOPhieuMuon;
import com.example.pnlib.DAO.DAOSach;
import com.example.pnlib.DAO.DAOThanhVien;
import com.example.pnlib.DTO.PhieuMuon;
import com.example.pnlib.DTO.Sach;
import com.example.pnlib.DTO.Thanhvien;
import com.example.pnlib.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;


public class FragmentPhieuMuon extends Fragment {
    RecyclerView rcv;
    FloatingActionButton fab;
    ArrayList<PhieuMuon> lstPM;
    EditText edDialogMaPM;
    Spinner spnTenThanhVienPM;
    Spinner spnTenSachPM;
    CheckBox chkTraSach;
    Button btnDialogLuuPM;
    Button btnDialogHuyPM;

    static DAOPhieuMuon daoPhieuMuon;
    AdapterPhieuMuon adapterPhieuMuon;
    PhieuMuon phieuMuon;

    AdapterSpinnerThanhVien adapterSpinnerThanhVien;
    ArrayList<Thanhvien> lstTV;
    DAOThanhVien daoThanhVien;
    Thanhvien thanhvien;
    int maTV;

    AdapterSpinnerSach adapterSpinnerSach;
    ArrayList<Sach> lstSach;
    DAOSach daoSach;
    Sach sach;
    int maSach, tienThue;
    int positionTV, positionSach;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @org.jetbrains.annotations.NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_phieumuon, container, false);

        rcv = view.findViewById(R.id.rcv_PM);
        fab = view.findViewById(R.id.fab_add_PM);
        daoPhieuMuon = new DAOPhieuMuon(getContext());
        phieuMuon = new PhieuMuon();
        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        rcv.setLayoutManager(manager);
        capNhatLv();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(getContext(), 0);
            }
        });
        return view;
    }

    protected void openDialog(final Context context, final int type) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_phieumuon, null);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
        edDialogMaPM = view.findViewById(R.id.ed_maPM);
        spnTenThanhVienPM = view.findViewById(R.id.spn_tenThanhVienPM);
        spnTenSachPM = view.findViewById(R.id.spn_tenSachPM);
        chkTraSach = view.findViewById(R.id.chk_traSach);
        btnDialogLuuPM = view.findViewById(R.id.btn_dialogLuuPM);
        btnDialogHuyPM = view.findViewById(R.id.btn_dialogHuyPM);

        // thanh vien
        daoThanhVien = new DAOThanhVien(context);
        lstTV = new ArrayList<>();
        lstTV = (ArrayList<Thanhvien>) daoThanhVien.getAll();
        adapterSpinnerThanhVien = new AdapterSpinnerThanhVien(context, lstTV);
        spnTenThanhVienPM.setAdapter(adapterSpinnerThanhVien);
        // lay ma tv
        spnTenThanhVienPM.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                maTV = lstTV.get(position).getMaTV();
                //Toast.makeText(context, "chọn " + lstTV.get(position).getMaTV(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // sach
        daoSach = new DAOSach(context);
        lstSach = new ArrayList<>();
        lstSach = (ArrayList<Sach>) daoSach.getAll();
        adapterSpinnerSach = new AdapterSpinnerSach(context, lstSach);
        spnTenSachPM.setAdapter(adapterSpinnerSach);
        //lay ma sach
        spnTenSachPM.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                maSach = lstSach.get(position).getMaSach();
                tienThue = lstSach.get(position).getGiaThue();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // kt insert hay update
        if (type != 0) {// typ1 = 0(update)
            edDialogMaPM.setText(String.valueOf(phieuMuon.getMaPM()));
            // lấy vị trí sách
            for (int i = 0; i < lstSach.size(); i++) {
                if (phieuMuon.getMaSach() == (lstSach.get(i).getMaSach())) {
                    positionSach = i;
                    //Log.e("aaaaaaaaaa", "openDialog: aaaaaaaaaaaaaaa");
                }
            }
            spnTenSachPM.setSelection(positionSach);


            // lấy vị trí thành viên
            for (int i = 0; i < lstTV.size(); i++) {
                if (phieuMuon.getMaTV() == (lstTV.get(i).getMaTV())) {
                    positionTV = i;
                    //Log.e("aaaaaaaaaa", "openDialog: aaaaaaaaaaaaaaa");
                }
            }
            spnTenThanhVienPM.setSelection(positionTV);


            // checkbox
            if (phieuMuon.getTraSach() == 1) {
                chkTraSach.setChecked(true);
            } else {
                chkTraSach.setChecked(false);
            }
        }

        btnDialogHuyPM.setOnClickListener(v -> alertDialog.dismiss());
        btnDialogLuuPM.setOnClickListener(v -> {
            if (validate() > 0) {
                phieuMuon = new PhieuMuon();
                phieuMuon.setMaSach(maSach);
                phieuMuon.setMaTV(maTV);
                long millis = System.currentTimeMillis();
                java.sql.Date date = new java.sql.Date(millis);
                phieuMuon.setNgay(date);
                phieuMuon.setTienThue(tienThue);
                SharedPreferences sharedPreferences = getContext().getSharedPreferences("Accout_file", Context.MODE_PRIVATE);
                String maTt = sharedPreferences.getString("USER", "");
                phieuMuon.setMaTT(maTt);
                if (chkTraSach.isChecked()) {
                    phieuMuon.setTraSach(1);
                } else {
                    phieuMuon.setTraSach(0);
                }

                if (type == 0) {
                    if (daoPhieuMuon.insert(phieuMuon) > 0) {
                        Toast.makeText(context, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Thêm thất bại", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    phieuMuon.setMaPM(Integer.parseInt(edDialogMaPM.getText().toString()));
                    Log.i("zzzzzzzzzzz", "onClick: " + phieuMuon);
                    if (daoPhieuMuon.update(phieuMuon) > 0) {
                        Toast.makeText(context, "Update thành công", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Update thất bại", Toast.LENGTH_SHORT).show();
                    }
                }
                capNhatLv();
                alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }


    private int validate() {
        int check = 1;
        if (lstTV.size() == 0) {
            Toast.makeText(getContext(), "Thành viên đang trống!" + "\n" + "Tạo thành viên trước!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        if (lstSach.size() == 0) {
            Toast.makeText(getContext(), "Sách đang trống!" + "\n" + "Tạo sách trước!", Toast.LENGTH_SHORT).show();
            check = -1;
            return check;
        }
        return check;
    }

    public void xoa(final String id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_xoa, null);
        builder.setView(view);

        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
        Button xoa = view.findViewById(R.id.btn_dialog_xoaTV);
        Button huy = view.findViewById(R.id.btn_dialog_huyTV);

        xoa.setOnClickListener(v -> {
            if (daoPhieuMuon.delete(Integer.parseInt(id)) > 0) {
                capNhatLv();
                alertDialog.dismiss();
                Toast.makeText(getContext(), "Đã xóa", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Xóa thất bại!", Toast.LENGTH_SHORT).show();
            }
        });
        huy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                Toast.makeText(getContext(), "Đã hủy", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void update(int position) {
        phieuMuon = lstPM.get(position);
        openDialog(getContext(), 1);
    }

    void capNhatLv() {
        lstPM = (ArrayList<PhieuMuon>) daoPhieuMuon.getAll();
        adapterPhieuMuon = new AdapterPhieuMuon(getActivity(), this, lstPM);
        rcv.setAdapter(adapterPhieuMuon);
    }

}
