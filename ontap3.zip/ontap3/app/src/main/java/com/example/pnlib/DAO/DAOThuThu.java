package com.example.pnlib.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.pnlib.DTO.ThuThu;
import com.example.pnlib.Database.DatabaseLib;

import java.util.ArrayList;
import java.util.List;

public class DAOThuThu {
    private DatabaseLib databaseLib;
    private SQLiteDatabase db;

    public DAOThuThu(Context context) {

        databaseLib = new DatabaseLib(context);
        db = databaseLib.getWritableDatabase();
    }

    public List<ThuThu> getAll() {
        String getAll = "SELECT* FROM thuThu";
        return getData(getAll);
    }

    public long insert(ThuThu thuThu) {
        ContentValues values = new ContentValues();
        values.put("maTT", thuThu.getMaTT());
        values.put("hoTen", thuThu.getHoTen());
        values.put("matKhau", thuThu.getMatKhau());
        long kq = db.insert("thuThu", null, values);
        return kq;
    }

    public int update(ThuThu thuThu) {
        ContentValues values = new ContentValues();
        values.put("matKhau", thuThu.getMatKhau());
        return db.update("thuThu", values, "maTT=?", new String[]{thuThu.getMaTT()});

    }

    public ThuThu getID(String id) {
        String sql = "SELECT* FROM thuThu WHERE maTT=?";
        List<ThuThu> list = getData(sql, id);
        return list.get(0);
    }

    public int delete(String id) {
        return db.delete("thuThu", "maTT=?", new String[]{id});
    }

    public boolean checkLogin(String user, String password) {
        String checkLogin = "SELECT *FROM thuThu WHERE maTT = ? AND matKhau = ?";
        Cursor cursor = db.rawQuery(checkLogin, new String[]{user, password});
        if (cursor.getCount() > 0) {
            return true;
        }
        return false;
    }

    public boolean checkUser(String user) {
        String checkLogin = "SELECT *FROM thuThu WHERE maTT = ? ";
        Cursor cursor = db.rawQuery(checkLogin, new String[]{user});
        if (cursor.getCount() > 0) {
            return true;
        }
        return false;

    }

    private ArrayList<ThuThu> getData(String sql, String... selectionArgs) {
        ArrayList<ThuThu> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, selectionArgs);

        while (cursor.moveToNext()) {
            ThuThu thuThu = new ThuThu();
            thuThu.setMaTT(cursor.getString(cursor.getColumnIndex("maTT")));
            thuThu.setHoTen(cursor.getString(cursor.getColumnIndex("hoTen")));
            thuThu.setMatKhau(cursor.getString(cursor.getColumnIndex("matKhau")));
            list.add(thuThu);
        }
        return list;

    }

}
