package com.example.ontap1;

public class HDChiTiet {
    String slXuat;
    String donGiaXuat;

    public String getSlXuat() {
        return slXuat;
    }

    public void setSlXuat(String slXuat) {
        this.slXuat = slXuat;
    }

    public String getDonGiaXuat() {
        return donGiaXuat;
    }

    public void setDonGiaXuat(String donGiaXuat) {
        this.donGiaXuat = donGiaXuat;
    }

    public HDChiTiet(String slXuat, String donGiaXuat) {
        this.slXuat = slXuat;
        this.donGiaXuat = donGiaXuat;
    }
}
