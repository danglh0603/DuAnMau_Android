package com.example.ontap1.ontap02;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ontap1.R;

public class main extends AppCompatActivity {

    private EditText edMaLoai;
    private EditText edMaSP;
    private EditText edSlNhap;
    private EditText edSoLxuat;
    private EditText edDgNhap;
    private EditText edDgXuat;
    private EditText edNgayNhap;
    private EditText edNgayXuat;
    private Button btnThem;
    private Button btnDs;
    private Button btnTongSlNhap;
    private Button btnTongSoLuongXuat;

    DAOot daOot;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main3);
        edMaLoai = findViewById(R.id.edMaLoai);
        edMaSP = findViewById(R.id.edMaSP);
        edSlNhap = findViewById(R.id.edSlNhap);
        edSoLxuat = findViewById(R.id.edSoLxuat);
        edDgNhap = findViewById(R.id.edDgNhap);
        edDgXuat = findViewById(R.id.edDgXuat);
        edNgayNhap = findViewById(R.id.edNgayNhap);
        edNgayXuat = findViewById(R.id.edNgayXuat);
        btnThem = findViewById(R.id.btnThem);
        btnDs = findViewById(R.id.btnDs);
        btnTongSlNhap = findViewById(R.id.btnTongSlNhap);
        btnTongSoLuongXuat = findViewById(R.id.btnTongSoLuongXuat);

        daOot = new DAOot(getApplicationContext());


        btnThem.setOnClickListener(v -> {
            String maLoai = edMaLoai.getText().toString();
            String maSp = edMaSP.getText().toString();
            String slNhap = edSlNhap.getText().toString();
            String slXuat = edSoLxuat.getText().toString();
            String dgNhap = edDgNhap.getText().toString();
            String dgXuat = edDgXuat.getText().toString();
            String ngayNhap = edNgayNhap.getText().toString();
            String ngayXuat = edNgayXuat.getText().toString();
            daOot.insert(maLoai, maSp, slNhap, slXuat, dgNhap, dgXuat, ngayNhap, ngayXuat);
            Toast.makeText(getApplicationContext(), "Them thanh cong", Toast.LENGTH_SHORT).show();
        });
        btnDs.setOnClickListener(v -> {
            Intent in = new Intent(main.this, listSp.class);
            startActivity(in);
        });

        btnTongSlNhap.setOnClickListener(v -> {
            Intent in = new Intent(main.this, sumNhaps.class);
            startActivity(in);
        });

    }
}