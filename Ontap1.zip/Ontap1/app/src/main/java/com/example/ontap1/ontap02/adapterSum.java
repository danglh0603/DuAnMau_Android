package com.example.ontap1.ontap02;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.ontap1.R;

import java.util.ArrayList;

public class adapterSum extends ArrayAdapter {
    ArrayList<SumNhap> list;
    private TextView tvMaSps;
    private TextView tvMLs;

    public adapterSum(@NonNull Context context, ArrayList<SumNhap> list) {
        super(context, 0, list);
        this.list = list;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items, null);

        SumNhap sumNhap = list.get(position);
        if (sumNhap != null) {
            tvMaSps = view.findViewById(R.id.tvMaSpS);
            tvMLs = view.findViewById(R.id.tvMLS);

            tvMaSps.setText("maTL: " + sumNhap.getMaTl());
            tvMLs.setText("soluong: " + sumNhap.getSlNhap());
        }


        return view;
    }
}
