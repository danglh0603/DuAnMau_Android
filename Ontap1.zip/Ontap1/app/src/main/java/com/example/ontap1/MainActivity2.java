package com.example.ontap1;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    ArrayList<CAU3> list;
    DAOsp daOsp;
    private ListView lst;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        lst = findViewById(R.id.lst);
        list = new ArrayList<>();
        daOsp = new DAOsp(getApplicationContext());
        list = daOsp.sumSpNhap();
        AdapterList adapterList = new AdapterList(getApplicationContext(), list);
        lst.setAdapter(adapterList);
    }
}