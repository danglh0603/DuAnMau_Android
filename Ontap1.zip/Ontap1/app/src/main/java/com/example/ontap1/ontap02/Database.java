package com.example.ontap1.ontap02;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class Database extends SQLiteOpenHelper {
    public Database(Context context) {
        super(context, "ONTAPi23.DB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE theLoai(" +
                "maTL TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE sanPham(" +
                "maTL TEXT ," +
                "maSp TEXT ," +
                "slNhap TEXT," +
                "ngayNhap TEXT," +
                "dgNhap TEXT )");
        sqLiteDatabase.execSQL("CREATE TABLE hoaDon(" +
                "maHD INTEGER PRIMARY KEY AUTOINCREMENT," +
                "maSp TEXT REFERENCES sanPham(maSP)," +
                "ngayXuat TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE ctHD(" +
                "maHD TEXT REFERENCES hoaDon(maHD)," +
                "maHDCT INTEGER PRIMARY KEY AUTOINCREMENT," +
                "slXuat TEXT," +
                "dgXuat TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
