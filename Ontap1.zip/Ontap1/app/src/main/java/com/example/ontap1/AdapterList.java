package com.example.ontap1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class AdapterList extends ArrayAdapter {
    private TextView tvMaSp;
    private TextView tvSlNhap;
    ArrayList<CAU3> list;

    public AdapterList(@NonNull Context context, ArrayList<CAU3> list) {
        super(context, 0, list);
        this.list = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter, null);
        CAU3 cau3 = list.get(position);
        if (cau3 != null) {
            tvMaSp = view.findViewById(R.id.tvMaSp);
            tvSlNhap = view.findViewById(R.id.tvSlNhap);

            tvMaSp.setText(cau3.getMaTl());
            tvSlNhap.setText(cau3.getSoLuongNhap());
        }


        return view;
    }
}
