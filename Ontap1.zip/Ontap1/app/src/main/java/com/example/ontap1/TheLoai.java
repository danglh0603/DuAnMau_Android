package com.example.ontap1;

public class TheLoai {
    String maLoai;

    public String getmaLoai() {
        return maLoai;
    }

    public void setmaLoai(String maLoai) {
        this.maLoai = maLoai;
    }

    public TheLoai(String maLoai) {
        this.maLoai = maLoai;
    }
}
