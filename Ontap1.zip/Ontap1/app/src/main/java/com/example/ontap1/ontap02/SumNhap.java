package com.example.ontap1.ontap02;

public class SumNhap {
    String maTl;
    int slNhap;

    public String getMaTl() {
        return maTl;
    }

    public void setMaTl(String maTl) {
        this.maTl = maTl;
    }

    public int getSlNhap() {
        return slNhap;
    }

    public void setSlNhap(int slNhap) {
        this.slNhap = slNhap;
    }

    public SumNhap() {
    }

    public SumNhap(String maTl, int slNhap) {
        this.maTl = maTl;
        this.slNhap = slNhap;
    }
}
