package com.example.ontap1.ontap02;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DAOot {
    Database database;
    SQLiteDatabase db;

    public DAOot(Context context) {
        database = new Database(context);
        db = database.getWritableDatabase();
    }

    public void insert(String maLoai, String maSp, String slNhap, String slXuat, String dgNhap, String dgXuat, String ngayNhap, String ngayXuat) {

        ContentValues values = new ContentValues();
        values.put("maTL", maLoai);

        ContentValues values1 = new ContentValues();
        values1.put("maTL", maLoai);
        values1.put("maSp", maSp);
        values1.put("slNhap", slNhap);
        values1.put("ngayNhap", ngayNhap);
        values1.put("dgNhap", dgNhap);

        ContentValues values2 = new ContentValues();
        values2.put("maSp", maSp);
        values2.put("ngayXuat", ngayXuat);

        ContentValues values3 = new ContentValues();
        values3.put("slXuat", slXuat);
        values3.put("dgXuat", dgXuat);

        db.insert("theLoai", null, values);
        db.insert("sanPham", null, values1);
        db.insert("hoaDon", null, values2);
        db.insert("ctHD", null, values3);
    }

    @SuppressLint("Range")
    public ArrayList<SanPham> getAll() {
        ArrayList<SanPham> list = new ArrayList();
        Cursor cursor = db.rawQuery("SELECT* FROM sanPham", null);
        while (cursor.moveToNext()) {
            SanPham sanPham = new SanPham();
            sanPham.setMaTL(cursor.getString(cursor.getColumnIndex("maTL")));
            sanPham.setMaSp(cursor.getString(cursor.getColumnIndex("maSp")));
            list.add(sanPham);
        }
        return list;
    }


    @SuppressLint("Range")
    public ArrayList<SumNhap> sumNhap() {
        ArrayList<SumNhap> list = new ArrayList<>();
        Cursor cursor =
                db.rawQuery("SELECT sanPham.maTL, sum(slNhap) as soluong FROM sanPham INNER JOIN theLoai on sanPham.maTL = theLoai.maTL" +
                        " GROUP BY theLoai.maTL", null);
        while (cursor.moveToNext()) {
            SumNhap sumNhap = new SumNhap();
            sumNhap.setMaTl(cursor.getString(cursor.getColumnIndex("maTL")));
            sumNhap.setSlNhap(Integer.parseInt(cursor.getString(cursor.getColumnIndex("soluong"))));
            list.add(sumNhap);
        }
        return list;
    }
}
