package com.example.ontap1.ontap02;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ontap1.R;

import java.util.ArrayList;

public class sumNhaps extends AppCompatActivity {
    DAOot daOot;
    ArrayList<SumNhap> list;
    private ListView lstS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sum_nhap);
        lstS = findViewById(R.id.lstS);

        daOot = new DAOot(getApplicationContext());
        list = daOot.sumNhap();
        adapterSum adapterSum = new adapterSum(getApplicationContext(), list);
        lstS.setAdapter(adapterSum);

    }
}