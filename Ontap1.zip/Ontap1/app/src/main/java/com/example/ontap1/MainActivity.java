package com.example.ontap1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edmaLoai;
    private EditText edmaSP;
    private EditText edSlNhap;
    private EditText edSlXuat;
    private EditText edDonGiaNhap;
    private EditText edDonGiaXuat;
    private EditText edNgayNhap;
    private EditText edNgayXuat;
    private Button btnC1;
    private Button btnC2;
    private Button btnC3;
    private Button btnC4;

    DAOsp daOsp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //

        daOsp = new DAOsp(this);
        edmaLoai = findViewById(R.id.edmaLoai);
        edmaSP = findViewById(R.id.edmaSP);
        edSlNhap = findViewById(R.id.edSlNhap);
        edSlXuat = findViewById(R.id.edSlXuat);
        edDonGiaNhap = findViewById(R.id.edDonGiaNhap);
        edDonGiaXuat = findViewById(R.id.edDonGiaXuat);
        edNgayNhap = findViewById(R.id.edNgayNhap);
        edNgayXuat = findViewById(R.id.edNgayXuat);
        btnC1 = findViewById(R.id.btnC1);
        btnC2 = findViewById(R.id.btnC2);
        btnC3 = findViewById(R.id.btnC3);
        btnC4 = findViewById(R.id.btnC4);
        //
        btnC2.setOnClickListener(v -> {
            String maLoai = edmaLoai.getText().toString();
            String maSP = edmaSP.getText().toString();
            String slNhap = edSlNhap.getText().toString();
            String slXuat = edSlXuat.getText().toString();
            String dongiaNhap = edDonGiaNhap.getText().toString();
            String donGiaXuat = edDonGiaXuat.getText().toString();
            String ngayNhap = edNgayNhap.getText().toString();
            String ngayXuat = edNgayXuat.getText().toString();
            if (maLoai.length() == 0 ||
                    maSP.length() == 0 ||
                    slNhap.length() == 0 ||
                    slXuat.length() == 0 ||
                    dongiaNhap.length() == 0 ||
                    donGiaXuat.length() == 0 ||
                    ngayNhap.length() == 0 ||
                    ngayXuat.length() == 0) {
                Toast.makeText(getApplicationContext(), "Phai nhap day du tong tin", Toast.LENGTH_SHORT).show();
                return;
            }

            SanPham sanPham = new SanPham(maLoai, maSP, slNhap, dongiaNhap, ngayNhap);
            TheLoai theLoai = new TheLoai(maLoai);
            HoaDon hoaDon = new HoaDon(ngayXuat);
            HDChiTiet hdChiTiet = new HDChiTiet(slXuat, donGiaXuat);

            if (daOsp.insertSP(sanPham) > 0 &&
                    daOsp.insertTL(theLoai) > 0 &&
                    daOsp.insertHD(hoaDon) > 0 &&
                    daOsp.insertCT(hdChiTiet) > 0) {
                Toast.makeText(getApplicationContext(), "Them thanh cong!", Toast.LENGTH_SHORT).show();
                edmaLoai.setText("");
                edmaSP.setText("");
                edSlNhap.setText("");
                edSlXuat.setText("");
                edDonGiaNhap.setText("");
                edDonGiaXuat.setText("");
                edNgayNhap.setText("");
                edNgayXuat.setText("");
            } else {
                Toast.makeText(getApplicationContext(), "Them that bai", Toast.LENGTH_SHORT).show();
            }

        });
        btnC3.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            startActivity(intent);

            //Toast.makeText(getApplicationContext(), "" + list, Toast.LENGTH_SHORT).show();
//            AlertDialog.Builder builder = new AlertDialog.Builder(getApplicationContext());
//            builder.setTitle("Thoong baso");
//            //builder.setMessage(list + "");
//            AlertDialog alertDialog = builder.create();
//            alertDialog.show();
        });

    }
}