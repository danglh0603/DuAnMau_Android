package com.example.ontap1;

public class SanPham {
    String maSp;
    String maTL;
    String slNhap;
    String donGiaNhap;
    String ngayNhap;

    public String getMaSp() {
        return maSp;
    }

    public void setMaSp(String maSp) {
        this.maSp = maSp;
    }

    public String getSlNhap() {
        return slNhap;
    }

    public void setSlNhap(String slNhap) {
        this.slNhap = slNhap;
    }

    public String getDonGiaNhap() {
        return donGiaNhap;
    }

    public void setDonGiaNhap(String donGiaNhap) {
        this.donGiaNhap = donGiaNhap;
    }

    public String getNgayNhap() {
        return ngayNhap;
    }

    public void setNgayNhap(String ngayNhap) {
        this.ngayNhap = ngayNhap;
    }

    public SanPham() {
    }

    public String getMaTL() {
        return maTL;
    }

    public void setMaTL(String maTL) {
        this.maTL = maTL;
    }

    public SanPham(String maSp, String maTL, String slNhap, String donGiaNhap, String ngayNhap) {
        this.maSp = maSp;
        this.maTL = maTL;
        this.slNhap = slNhap;
        this.donGiaNhap = donGiaNhap;
        this.ngayNhap = ngayNhap;
    }
}
