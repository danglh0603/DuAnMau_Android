package com.example.ontap1;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DAOsp {
    DatabaseSP databaseSP;
    SQLiteDatabase db;

    public DAOsp(Context context) {
        databaseSP = new DatabaseSP(context);
        db = databaseSP.getWritableDatabase();
    }


    public long insertTL(TheLoai theLoai) {
        ContentValues values = new ContentValues();
        values.put("maLoai", theLoai.getmaLoai());
        return db.insert("theLoai", null, values);
    }

    public long insertSP(SanPham sanPham) {
        ContentValues values = new ContentValues();
        values.put("maLoai", sanPham.getMaTL());
        values.put("maSp", sanPham.getMaSp());
        values.put("slNhap", sanPham.getSlNhap());
        values.put("donGiaNhap", sanPham.getDonGiaNhap());
        values.put("ngayNhap", sanPham.getNgayNhap());
        return db.insert("sanPham", null, values);
    }

    public long insertHD(HoaDon hoaDon) {
        ContentValues values = new ContentValues();
        values.put("ngayXuat", hoaDon.getNgayXuat());
        return db.insert("hoaDon", null, values);
    }

    public long insertCT(HDChiTiet hdChiTiet) {
        ContentValues values = new ContentValues();
        values.put("slXuat", hdChiTiet.getSlXuat());
        values.put("donGiaXuat", hdChiTiet.getDonGiaXuat());
        return db.insert("HDChitiet", null, values);
    }

    @SuppressLint("Range")
    public SanPham getID(String id) {
        String sql = "SELECT* FROM SanPham WHERE maSp= ?";
        SanPham sanPham = new SanPham();
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        if (cursor.moveToFirst()) {
            sanPham.setMaSp(cursor.getString(cursor.getColumnIndex("maSp")));
            sanPham.setMaSp(cursor.getString(cursor.getColumnIndex("slNhap")));
        }
        return sanPham;
    }

    @SuppressLint("Range")
    public ArrayList<CAU3> sumSpNhap() {
        String getSum = "SELECT sanPham.maTL, sum(slNhap) as slNhap FROM sanPham INNER JOIN theLoai on sanPham.maTL = theLoai.maTL" +
                " GROUP BY sanPham.maTL";
        ArrayList<CAU3> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(getSum, null);
        while (cursor.moveToNext()) {
            CAU3 cau3 = new CAU3();
            cau3.setSoLuongNhap(cursor.getString(cursor.getColumnIndex("slNhap")));
            cau3.setMaTl(cursor.getString(cursor.getColumnIndex("maTL")));
            list.add(cau3);
        }
        return list;
    }

    @SuppressLint("Range")
    public ArrayList<CAU3> sumSpXuat() {
        String getSum = "SELECT maSP, sum(slNhap) as slNhap FROM sanPham GROUP BY maSP";
        ArrayList<CAU3> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(getSum, null);
        while (cursor.moveToNext()) {
            CAU3 cau3 = new CAU3();
            cau3.setSoLuongNhap(cursor.getString(cursor.getColumnIndex("slNhap")));
            cau3.setMaTl(cursor.getString(cursor.getColumnIndex("maSP")));
            list.add(cau3);
        }
        return list;
    }

}
