package com.example.ontap1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseSP extends SQLiteOpenHelper {
    public DatabaseSP(@Nullable Context context) {
        super(context, "databaseSP1.db", null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE theLoai(maLoai TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE sanPham(" +
                "maSP TEXT," +
                "slNhap TEXT," +
                "donGiaNhap TEXT," +
                "ngayNhap TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE hoaDon(ngayXuat TEXT )");
        sqLiteDatabase.execSQL("CREATE TABLE HDChitiet(slXuat TEXT ," +
                "donGiaXuat TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
