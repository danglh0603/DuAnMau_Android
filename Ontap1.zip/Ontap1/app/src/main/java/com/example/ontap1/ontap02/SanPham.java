package com.example.ontap1.ontap02;

public class SanPham {
    String maTL, maSp, slNhap, ngayNhap, dgNhap;

    public String getMaTL() {
        return maTL;
    }

    public void setMaTL(String maTL) {
        this.maTL = maTL;
    }

    public String getMaSp() {
        return maSp;
    }

    public void setMaSp(String maSp) {
        this.maSp = maSp;
    }

    public String getSlNhap() {
        return slNhap;
    }

    public void setSlNhap(String slNhap) {
        this.slNhap = slNhap;
    }

    public String getNgayNhap() {
        return ngayNhap;
    }

    public void setNgayNhap(String ngayNhap) {
        this.ngayNhap = ngayNhap;
    }

    public String getDgNhap() {
        return dgNhap;
    }

    public void setDgNhap(String dgNhap) {
        this.dgNhap = dgNhap;
    }

    public SanPham() {
    }

    public SanPham(String maTL, String maSp, String slNhap, String ngayNhap, String dgNhap) {
        this.maTL = maTL;
        this.maSp = maSp;
        this.slNhap = slNhap;
        this.ngayNhap = ngayNhap;
        this.dgNhap = dgNhap;
    }
}
