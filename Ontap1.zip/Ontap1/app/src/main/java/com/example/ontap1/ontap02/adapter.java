package com.example.ontap1.ontap02;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.ontap1.R;

import java.util.ArrayList;

public class adapter extends ArrayAdapter {
    ArrayList<SanPham> list;
    private TextView tvMaSp;
    private TextView tvML;

    public adapter(@NonNull Context context, ArrayList<SanPham> list) {
        super(context, 0, list);
        this.list = list;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, null);

        SanPham sanPham = list.get(position);
        if (sanPham != null) {
            tvMaSp = view.findViewById(R.id.tvMaSp);
            tvML = view.findViewById(R.id.tvML);

            tvMaSp.setText("maSp: " + sanPham.getMaSp());
            tvML.setText("maLoai: " + sanPham.getMaTL());
        }


        return view;
    }
}
