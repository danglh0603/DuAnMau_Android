package com.example.ontap1.ontap02;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ontap1.R;

import java.util.ArrayList;

public class listSp extends AppCompatActivity {

    private ListView lstView;
    ArrayList<SanPham> list;
    DAOot daOot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_sp);
        lstView = findViewById(R.id.lstView);
        daOot = new DAOot(getApplicationContext());
        list = daOot.getAll();
        adapter adapter = new adapter(getApplicationContext(), list);
        lstView.setAdapter(adapter);
    }
}