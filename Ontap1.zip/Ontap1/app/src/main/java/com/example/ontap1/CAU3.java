package com.example.ontap1;

public class CAU3 {
    String maTl;
    String soLuongNhap;

    public String getMaTl() {
        return maTl;
    }

    public void setMaTl(String maTl) {
        this.maTl = maTl;
    }

    public String getSoLuongNhap() {
        return soLuongNhap;
    }

    public void setSoLuongNhap(String soLuongNhap) {
        this.soLuongNhap = soLuongNhap;
    }

    public CAU3() {
    }

    public CAU3(String maTl, String soLuongNhap) {
        this.maTl = maTl;
        this.soLuongNhap = soLuongNhap;
    }
}
