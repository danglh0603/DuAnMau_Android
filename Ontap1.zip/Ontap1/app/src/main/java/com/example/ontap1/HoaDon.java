package com.example.ontap1;

public class HoaDon {
    String ngayXuat;

    public String getNgayXuat() {
        return ngayXuat;
    }

    public void setNgayXuat(String ngayXuat) {
        this.ngayXuat = ngayXuat;
    }

    public HoaDon(String ngayXuat) {
        this.ngayXuat = ngayXuat;
    }
}
