package com.example.pnlib.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pnlib.DTO.ThuThu;
import com.example.pnlib.Fragment.FragmentThemTaiKhoan;
import com.example.pnlib.R;

import java.util.ArrayList;

public class AdapterThemThuThu extends RecyclerView.Adapter<AdapterThemThuThu.ViewHolder> {
    private Context context;
    FragmentThemTaiKhoan fragmentLoaiSach;
    private ArrayList<ThuThu> list;

    public AdapterThemThuThu(Context context, FragmentThemTaiKhoan fragmentLoaiSach, ArrayList<ThuThu> list) {
        this.context = context;
        this.fragmentLoaiSach = fragmentLoaiSach;
        this.list = list;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_thuthu, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final ThuThu thuThu = list.get(position);
        if (thuThu != null) {

            if (position % 2 == 0) {
                holder.tvMaTT.setText("Tên đăng nhập: " + thuThu.getMaTT());
                holder.tvMaTT.setTextColor(Color.GREEN);
                holder.tvTenTT.setText("Tên thủ thư: " + thuThu.getHoTen());
                holder.tvTenTT.setTextColor(Color.GREEN);
            } else {
                holder.tvMaTT.setText("Tên đăng nhập: " + thuThu.getMaTT());
                holder.tvMaTT.setTextColor(Color.RED);
                holder.tvTenTT.setText("Tên thủ thư: " + thuThu.getHoTen());
                holder.tvTenTT.setTextColor(Color.RED);
            }
            holder.btnXoaLS.setOnClickListener(v -> {
                if (position == 0) {
                    Toast.makeText(context, "Không thể xóa admin", Toast.LENGTH_SHORT).show();
                } else {
                    fragmentLoaiSach.xoa(thuThu.getMaTT());
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        if (list != null) {
            return list.size();
        }
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private CardView adapterCardView;
        private TextView tvMaTT;
        private TextView tvTenTT;
        private Button btnXoaLS;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            adapterCardView = itemView.findViewById(R.id.adapterCardView);
            tvMaTT = itemView.findViewById(R.id.tv_maTT);
            tvTenTT = itemView.findViewById(R.id.tv_tenTT);
            btnXoaLS = itemView.findViewById(R.id.btn_xoaLS);

        }
    }
}
