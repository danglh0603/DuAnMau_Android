package com.example.pnlib;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pnlib.DAO.DAOThuThu;

public class Login extends AppCompatActivity {

    private DAOThuThu daoThuThu;


    private EditText edTenDangNhap;
    private EditText edMatKhau;
    private Button btnDangNhap;
    private CheckBox checkBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // anh xa
        edTenDangNhap = findViewById(R.id.ed_tenDangNhap);
        edMatKhau = findViewById(R.id.ed_matKhau);
        btnDangNhap = findViewById(R.id.btn_dangNhap);
        checkBox = findViewById(R.id.chk_Remember);

        // tao doi tuong dao
        daoThuThu = new DAOThuThu(Login.this);

        // ghi nho mk
        SharedPreferences sharedPreferences = getSharedPreferences("Accout_file", MODE_PRIVATE);
        edTenDangNhap.setText(sharedPreferences.getString("USER", ""));
        edMatKhau.setText(sharedPreferences.getString("PASS", ""));
        checkBox.setChecked(sharedPreferences.getBoolean("REMEMBER", false));

        //
        btnDangNhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkLogin();
            }
        });

    }

    private void checkLogin() {
        String user = edTenDangNhap.getText().toString();
        String pass = edMatKhau.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Không để trống các trường!", Toast.LENGTH_SHORT).show();
        } else {
            if (daoThuThu.checkLogin(user, pass) == true) {
                Toast.makeText(getApplicationContext(), "Xin chào " + user, Toast.LENGTH_SHORT).show();
                rememberAccount(user, pass, checkBox.isChecked());
                Intent intent = new Intent(Login.this, Main.class);
                intent.putExtra("user", user);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(getApplicationContext(), "Thông tin đăng nhập không chính xác!", Toast.LENGTH_SHORT).show();
            }
        }

    }

    // ghi nho tai khoan
    private void rememberAccount(String user, String pass, boolean status) {
        SharedPreferences sharedPreferences = getSharedPreferences("Accout_file", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (status == false) {
            editor.clear();
        } else {
            editor.putString("USER", user);
            editor.putString("PASS", pass);
            editor.putBoolean("REMEMBER", true);
        }
        editor.commit();
    }


    // thoat
    public void huy() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
        View view1 = LayoutInflater.from(Login.this).inflate(R.layout.dialog_thoat, null);
        builder.setView(view1);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();

        Button btn_thoat = view1.findViewById(R.id.btn_Thoat);
        Button btn_huy = view1.findViewById(R.id.btn_Huy);
        btn_thoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                System.exit(0);

            }
        });

        btn_huy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
    }

    @Override
    public void onBackPressed() {
        huy();
    }
}