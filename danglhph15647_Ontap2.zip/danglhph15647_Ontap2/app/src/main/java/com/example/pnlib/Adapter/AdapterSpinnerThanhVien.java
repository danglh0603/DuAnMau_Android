package com.example.pnlib.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.pnlib.DTO.Thanhvien;
import com.example.pnlib.R;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class AdapterSpinnerThanhVien extends ArrayAdapter<Thanhvien> {
    private Context context;
    private List<Thanhvien> lstThanhVien;
    TextView tvTenTv, tvMaTv;

    public AdapterSpinnerThanhVien(@NonNull Context context, List<Thanhvien> lstThanhVien) {
        super(context, 0, lstThanhVien);
        this.context = context;
        this.lstThanhVien = lstThanhVien;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater =
                    (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.adapter_spinner_thanhvien, null);
        }
        final Thanhvien thanhvien = lstThanhVien.get(position);
        if (thanhvien != null) {
            tvMaTv = view.findViewById(R.id.tv_spinner_maTV);
            tvTenTv = view.findViewById(R.id.tv_spinner_tenTV);

            tvMaTv.setText(thanhvien.getMaTV() + ".");
            tvTenTv.setText(thanhvien.getHoTen());
        }

        return view;
    }

    @Override
    public View getDropDownView(int position, @Nullable @org.jetbrains.annotations.Nullable View convertView, @NonNull @NotNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater
                    = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.adapter_drop_spinner_thanhvien, null);
        }
        final Thanhvien thanhvien = lstThanhVien.get(position);
        if (thanhvien != null) {
            tvTenTv = view.findViewById(R.id.tv_spinner_tenTV);
            tvMaTv = view.findViewById(R.id.tv_spinner_maTV);
            tvMaTv.setText(thanhvien.getMaTV() + ".");
            tvTenTv.setText(thanhvien.getHoTen());
        }
        return view;
    }
}
