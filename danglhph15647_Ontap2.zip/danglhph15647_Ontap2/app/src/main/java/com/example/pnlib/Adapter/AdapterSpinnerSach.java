package com.example.pnlib.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.pnlib.DTO.Sach;
import com.example.pnlib.DTO.Thanhvien;
import com.example.pnlib.R;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class AdapterSpinnerSach extends ArrayAdapter<Sach> {
    private Context context;
    private List<Sach> lstSach;
    TextView tvMaSach, tvTenSach;

    public AdapterSpinnerSach(@NonNull Context context, List<Sach> lstSach) {
        super(context, 0, lstSach);
        this.context = context;
        this.lstSach = lstSach;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater =
                    (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.adapter_spinner_sach, null);
        }
        final Sach sach = lstSach.get(position);
        if (sach != null) {
            tvMaSach = view.findViewById(R.id.tv_spinner_maSach);
            tvTenSach = view.findViewById(R.id.tv_spinner_tenSach);

            tvMaSach.setText(sach.getMaSach()+".");
            tvTenSach.setText(sach.getTenSach());
        }

        return view;
    }

    @Override
    public View getDropDownView(int position, @Nullable @org.jetbrains.annotations.Nullable View convertView, @NonNull @NotNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater
                    = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.adapter_drop_spinner_sach, null);
        }
        final Sach sach = lstSach.get(position);
        if (sach != null) {
            tvMaSach = view.findViewById(R.id.tv_spinner_maSach);
            tvTenSach = view.findViewById(R.id.tv_spinner_tenSach);
            tvMaSach.setText(sach.getMaSach()+".");
            tvTenSach.setText(sach.getTenSach());
        }
        return view;
    }
}
