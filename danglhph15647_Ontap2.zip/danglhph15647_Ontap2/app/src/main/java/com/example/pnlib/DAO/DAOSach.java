package com.example.pnlib.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.pnlib.DTO.Sach;
import com.example.pnlib.Database.DatabaseLib;

import java.util.ArrayList;

public class DAOSach {
    private DatabaseLib databaseLib;
    private SQLiteDatabase db;

    public DAOSach(Context context) {
        databaseLib = new DatabaseLib(context);
        db = databaseLib.getWritableDatabase();

    }

    public Sach getID(String id) {
        String sql = "SELECT* FROM Sach WHERE maSach= ?";
        Sach sach = new Sach();
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        if (cursor.moveToFirst()) {
            sach.setMaSach(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maSach"))));
            sach.setTenSach(cursor.getString(cursor.getColumnIndex("tenSach")));
            sach.setGiaThue(Integer.parseInt(cursor.getString(cursor.getColumnIndex("giaThue"))));
            sach.setKhuyenMai(Integer.parseInt(cursor.getString(cursor.getColumnIndex("khuyenMai"))));
            sach.setMaLoai(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maLoai"))));
        }
        return sach;
    }


    public long insert(Sach sach) {
        ContentValues values = new ContentValues();
        values.put("tenSach", sach.getTenSach());
        values.put("giaThue", sach.getGiaThue());
        values.put("khuyenMai", sach.getKhuyenMai());
        values.put("maLoai", sach.getMaLoai());
        return db.insert("Sach", null, values);
    }

    public int update(Sach sach) {

        ContentValues values = new ContentValues();
        values.put("tenSach", sach.getTenSach());
        values.put("giaThue", sach.getGiaThue());
        values.put("khuyenMai", sach.getKhuyenMai());
        values.put("maLoai", sach.getMaLoai());
        return db.update("Sach", values, "maSach=?", new String[]{String.valueOf(sach.getMaSach())});
    }

    public int delete(int id) {
        return db.delete("Sach", "maSach = ?", new String[]{String.valueOf(id)});
    }

    public ArrayList<Sach> getAll() {
        String sql = "SELECT* FROM Sach";
        return getData(sql);
    }

    private ArrayList<Sach> getData(String sql, String... selectionArgs) {
        ArrayList<Sach> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, selectionArgs);
        while (cursor.moveToNext()) {
            Sach sach = new Sach();
            sach.setMaSach(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maSach"))));
            sach.setTenSach(cursor.getString(cursor.getColumnIndex("tenSach")));
            sach.setGiaThue(Integer.parseInt(cursor.getString(cursor.getColumnIndex("giaThue"))));
            sach.setKhuyenMai(Integer.parseInt(cursor.getString(cursor.getColumnIndex("khuyenMai"))));
            sach.setMaLoai(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maLoai"))));
            list.add(sach);
        }
        return list;

    }

}
