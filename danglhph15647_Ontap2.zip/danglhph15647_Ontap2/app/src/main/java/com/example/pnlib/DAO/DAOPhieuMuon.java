package com.example.pnlib.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.pnlib.DTO.PhieuMuon;
import com.example.pnlib.Database.DatabaseLib;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


public class DAOPhieuMuon {
    private DatabaseLib databaseLib;
    private SQLiteDatabase db;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public DAOPhieuMuon(Context context) {
        databaseLib = new DatabaseLib(context);
        db = databaseLib.getWritableDatabase();
    }

    public long insert(PhieuMuon phieuMuon) {
        ContentValues values = new ContentValues();
        values.put("maTT", phieuMuon.getMaTT());
        values.put("maTV", phieuMuon.getMaTV());
        values.put("maSach", phieuMuon.getMaSach());
        values.put("ngay", String.valueOf(phieuMuon.getNgay()));
        values.put("traSach", phieuMuon.getTraSach());
        values.put("tienThue", phieuMuon.getTienThue());
        return db.insert("phieuMuon", null, values);
    }

    public int update(PhieuMuon phieuMuon) {
        ContentValues values = new ContentValues();
        values.put("maTV", phieuMuon.getMaTV());
        values.put("maSach", phieuMuon.getMaSach());
        values.put("traSach", phieuMuon.getTraSach());
        values.put("tienThue", phieuMuon.getTienThue());
        return db.update("phieuMuon", values, "maPM=?", new String[]{String.valueOf(phieuMuon.getMaPM())});
    }

    public int delete(int id) {
        return db.delete("phieuMuon", "maPM = ?", new String[]{String.valueOf(id)});
    }

    // getAll
    public List<PhieuMuon> getAll() {
        String sql = "SELECT*FROM phieuMuon";
        return getData(sql);
    }

    public PhieuMuon getID(String id) {
        String sql = "SELECT* FROM phieuMuon maPM=?";
        List<PhieuMuon> list = getData(sql, id);
        return list.get(0);
    }

    private List<PhieuMuon> getData(String sql, String... selectionArgs) {
        List<PhieuMuon> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, selectionArgs);
        while (cursor.moveToNext()) {
            PhieuMuon phieuMuon = new PhieuMuon();
            phieuMuon.setMaPM(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maPM"))));
            phieuMuon.setMaTT(cursor.getString(cursor.getColumnIndex("maTT")));
            phieuMuon.setMaTV(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maTV"))));
            phieuMuon.setMaSach(Integer.parseInt(cursor.getString(cursor.getColumnIndex("maSach"))));
            try {
                phieuMuon.setNgay(sdf.parse(cursor.getString(cursor.getColumnIndex("ngay"))));
            } catch (Exception e) {
                e.printStackTrace();
            }

            phieuMuon.setTraSach(Integer.parseInt(cursor.getString(cursor.getColumnIndex("traSach"))));
            phieuMuon.setTienThue(Integer.parseInt(cursor.getString(cursor.getColumnIndex("tienThue"))));
            list.add(phieuMuon);
        }
        return list;

    }

}
